let ocbTopNotice = (function (){
	const unreadCount = 0;
	const noticeListLimitCount = 100;
	let noticeCnt = 0;
	let ureadCntArea = "#topUreadCntNoti";
	let c = {}

	c.procPriMessage = function(msg){
		if(msg && msg !== ''){
			let obj = JSON.parse(msg);
			if(!obj.rcvInqireDt || ocb.cmm.getValue(obj.rcvInqireDt) === '') {
				upUnReadCount();
			}
			addNoticeList(obj, 'first');
			listLimitCheck();
		}
	}

	c.init = function(){
		ocb.wscli.init(c.procPriMessage);
		ocb.wscli.open();
		c.loadData();
	}

	c.loadData = function(){
		loadMyTopNoticeList();
	}

	let loadMyTopNoticeList = function(){
		ocb.restcli.exchangeAsync('GET', page_context_path + '/rest/system/notice/admin/main/list', {}
			, ocb.restcli.contentType.formurlencoded, true, function (res) {
				if (res.code === 'OK') {
					let retObj = res.data;
					if (retObj) {
						printTrace(">>> loadMyTopNoticeList:", retObj);
						let unreadCount = retObj.unReadCount ? retObj.unReadCount:0;
						if(unreadCount > 0) {
							$(ureadCntArea).text(''+ unreadCount);
							$(ureadCntArea).removeClass('hide_object');
						}
						let notiList = retObj.noticeList ? retObj.noticeList:[];
						if(notiList && notiList.length && notiList.length > 0){
							notiList.forEach(function(ele){
								addNoticeList(ele);
							});
						}
					}else{
						printTrace(">>> [loadMyTopNoticeList]:", "["+ dataLoadFailMsg +"]", retObj);
					}
				}else{
					printTrace(">>> [loadMyTopNoticeList]:", "["+ dataLoadFailMsg +"]");
				}
			}, function (res) {
				printTrace(">>> [loadMyTopNoticeList]:", "["+ dataLoadFailMsg +"]");
			});
	}

	let sendSetNoticeReadDt = function(msgId, rcvCmpnyId, rcvEmpId){
		let param = {};
		param.msgId = msgId;
		let tgtId = '#N' + msgId + '' + rcvCmpnyId + '' + rcvEmpId;
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/system/notice/readdt/set', param
			, ocb.restcli.contentType.formurlencoded, true, function (res) {
				if (res.code === 'OK') {
					let retObj = res.data;
					if (retObj && retObj > 0) {
						printTrace(">>> sendSetNoticeReadDt:OK", retObj);
						downUnReadCount();
						$(tgtId).addClass("read");
						$(tgtId).attr('datareaddt', retObj);
					}else{
						printTrace(">>> [sendSetNoticeReadDt]:fail", retObj);
					}
				}else{
					printTrace(">>> [sendSetNoticeReadDt]:fail", res);
				}
			}, function (res) {
				printTrace(">>> [sendSetNoticeReadDt]::fail", res);
			});
	}

	let listLimitCheck = function(){
		let tgtRowObj = $("#notice-row a");
		let count = tgtRowObj && tgtRowObj.length ? tgtRowObj.length:0;
		if((count) > noticeListLimitCount){
			let rmCount = count - noticeListLimitCount;
			for(let c=0;c<rmCount;c++){
				$("#notice-row a:last").remove();
				$("#notice-row hr:last").remove();
			}
		}
	}

	let downUnReadCount = function(){
		let cCount = $(ureadCntArea).html();
		if(!cCount || cCount === ''){
			cCount = 0;
		}
		try{
			cCount = parseInt(cCount);
		}catch (_e){
			cCount = 0;
			printError("downUnReadCount parsing error:", _e);
		}
		$(ureadCntArea).html(''+ (cCount - 1 > 0 ? cCount - 1:'') );
		if(cCount - 1 <= 0) {
			$(ureadCntArea).addClass('hide_object');
		}
	}

	let upUnReadCount = function(){
		let cCount = $(ureadCntArea).html();
		if(!cCount || cCount === ''){
			cCount = 0;
		}

		try{
			cCount = parseInt(cCount);
		}catch (_e){
			cCount = 0;
			printError("upUnReadCount parsing error:", _e);
		}
		$(ureadCntArea).html(''+ (cCount+1) );
		if(cCount+1 > 0) {
			$(ureadCntArea).removeClass('hide_object');
		}
	}

	c.readMarkProc = function(msgId, rcvCmpnyId, rcvEmpId){
		let tgtId = '#N' + msgId + '' + rcvCmpnyId + '' + rcvEmpId;
		let cnReadDt =  $(tgtId).attr('datareaddt');
		console.log("[readMarkProc][cnReadDt]", cnReadDt, ocb.cmm.getValue(cnReadDt) === '');
		if(ocb.cmm.getValue(cnReadDt) === '') {
			sendSetNoticeReadDt(msgId, rcvCmpnyId, rcvEmpId);
		}
		fnAutoClickSideMenu('M_AS1500');
		open_object('alarm', 'c');
	}
	// {msgId:"1", dtlGbCd:"ALM", msgSj:"test1", sndngDt:1607476324783, rcvCmpnyId:"C1002", rcvEmpId:"1002", rcvInqireDt:null, rcvGbCd:''}
	let addNoticeList = function(obj, gb){
		if(noticeCnt === 0){
			$(".alarm_content_item.no_item").remove();
			noticeCnt = 1;
		}
		let rowHtml = '<a href="javascript:ocbTopNotice.readMarkProc(\''+ ocb.cmm.getValue(obj.msgId) +'\',\''+ ocb.cmm.getValue(obj.rcvCmpnyId) +'\',\''+ ocb.cmm.getValue(obj.rcvEmpId) +'\');" class="">'
			+ '<div id="N'+ (ocb.cmm.getValue(obj.msgId) +''+ ocb.cmm.getValue(obj.rcvCmpnyId) +''+ ocb.cmm.getValue(obj.rcvEmpId)) +'" class="alarm_content_item'+ (obj.rcvInqireDt && obj.rcvInqireDt > 0 ? ' read':'') +'" datareaddt='+ ocb.cmm.getValue(obj.rcvInqireDt) +'>'
			+ '<div class="icon_block txt-colored-blue">'
			+ '<i class="fas fa-unlock"></i>'
			+ '</div>'
			+ '<div class="txt_block">'
			+ '<div class="txt-colored-black size-16 txt_ellipsis padding_t_5">'+ ocb.cmm.getValue(obj.msgSj) +'</div>'
			+ '<p class="size-12 nomargin txt-colored-grey padding_t_5">'+ moment(obj.sndngDt).format('YYYY-MM-DD HH:mm') +'</p>'
			+ '</div>'
			+ '</div>'
			+ '</a>'
			+ '<hr class="nomargin alarm_content_hr">';
		if(gb && gb === 'first'){
			let oldRowObj = $("#notice-row a");
			if(oldRowObj && oldRowObj.length > 0) { //<a href="#" class=""></a>
				$("#notice-row a:first").before(rowHtml);
			}else{
				$("#notice-row").append(rowHtml);
			}
		}else {
			$("#notice-row").append(rowHtml);
		}
	}

	return c;
})();