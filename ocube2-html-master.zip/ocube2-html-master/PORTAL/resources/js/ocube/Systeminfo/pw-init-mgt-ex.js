var pwIninMgt = (function () {
    let p = {};
    p.dlngStList = [];
    p.pwInitGrid;  // 초기화요청 목록 그리드
    p.pwInitData = [];
    p.modalPwInitGrid;   // 모달 초기화요청 목록 그리드
    p.modalPwInitData = [];

    let g_msg;
    let g_c_msg = message.springMsg;	// 공통 properties msg

    p.init = function(globalOpt) {
        g_msg = globalOpt.springMsg;
        renderComp(this);
        initDataLoad(this);
    };

    let renderComp = function (obj) {
        createPwInitGrid();
    };

    let initDataLoad = function (obj) {
        // 일자 setting
        let mNow = moment();
        let g_mBeginDd = mNow.clone().add(-3, 'months');
        let g_mEndDd = mNow.clone();
        SBUxMethod.set('picker_beginDd', g_mBeginDd.format('YYYYMMDD'));
        SBUxMethod.set('picker_endDd', g_mEndDd.format('YYYYMMDD'));

        // 처리상태 selectbox 공통코드 적용
        p.dlngStList = ocb.cmm.getCmmnList('admin.login.init.dlngStNm');
        p.dlngStList.unshift({cdNm : g_c_msg.all, cd : ''});
        SBUxMethod.refresh('select_dlngSt');

        getPwInitList();  // 초기화 요청 목록 조회
    };

    // [API] 비밀번호 초기화 요청 리스트 조회
    let getPwInitList = function (){
        let param = ocb.cmm.getGridPagingParam(p.pwInitGrid);
        param.beginDd = moment(SBUxMethod.get('picker_beginDd')).format('YYYY-MM-DD');
        param.endDd = moment(SBUxMethod.get('picker_endDd')).format('YYYY-MM-DD');
        param.empNm = SBUxMethod.get('input_empNm');
        param.dlngSt = SBUxMethod.getValue('select_dlngSt');
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/login/init/page/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            p.pwInitData = res.data.list;
            //console.log('res.data.list > ' , res.data.list);
            p.pwInitGrid.setPageTotalCount(res.data.totalCnt); // 데이터의 총 건수를 'setPageTotalCount' 메소드에 setting
            p.pwInitGrid.refresh();
        }, function(res){
            alert(g_msg.alertMsgFailPwInitList);
        });
    }

    // [API] 비밀번호 초기화
    let setPwInit = function (param){
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/login/init/pw/init', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            alert(g_msg.alertMsgOkPwInit);
            SBUxMethod.closeModal('modal_pwInit');
            getPwInitList();
        }, function(res){
            alert(g_msg.alertMsgFailPwInit);
        });
    }

    let createPwInitGrid = function () {
        let paging = { 'type' : 'page', 'count' : 5, 'size' : 10, 'showgoalpageui': true };	// 페이징 처리
        p.pwInitGrid = sbuxComponent.createGrid( 'pwInitGridArea', 'pwIninMgt.pwInitGrid','pwIninMgt.pwInitData', pwDataGridColumns(), false, paging);
        p.pwInitGrid.bind('afterrefresh', 'pwIninMgt.pwInitGridAfterRefresh');
        p.pwInitGrid.bind( "beforepagechanged" , "pwIninMgt.fnPagingPwInitGrid" );
    };

    let pwDataGridColumns = function(){
        return [
            {
                caption : ['']
                , ref : 'chkYn'
                , width : '5%'
                , style : 'text-align:center'
                , type : 'checkbox'
                , typeinfo : {
                    fixedcellcheckbox : {
                        usemode : true
                        , rowindex : 0
                    }
                }
            }
            , {
                caption : [g_c_msg.gridCol.applyDt]
                , ref : 'insertDt'
                , width : '17%'
                , style : 'text-align:center'
                , type : 'output'
                , format : {
                    type :'custom'
                    , callback : function (val){
                        let d = moment(new Date(Number(val)));
                        return d.format('YYYY-MM-DD HH:mm:ss');
                    }
                }
            }
            , {
                caption : [g_c_msg.gridCol.id]
                , ref : 'requstLoginId'
                , width : '10%'
                , style : 'text-align:center'
                , type : 'output'
            }
            , {
                caption : [g_c_msg.gridCol.cmpny]
                , ref : 'requstCmpnyNm'
                , width : '11%'
                , style : 'text-align:center'
                , type : 'output'
            }
            , {
                caption : [g_c_msg.gridCol.dept]
                , ref : 'requstDeptNm'
                , width : '12%'
                , style : 'text-align:center'
                , type : 'output'
            }
            , {
                caption : [g_c_msg.gridCol.empNm]
                , ref : 'requstEmpNm'
                , width : '10%'
                , style : 'text-align:center'
                , type : 'output'
            }
            ,{
                caption : [g_c_msg.gridCol.conectIp]
                , ref : 'requstConectIp'
                , width : '15%'
                , style : 'text-align:center'
                , type : 'output'
            }
            ,{
                caption : [g_c_msg.gridCol.state]
                , ref : 'dlngSt'
                , width : '8%'
                , style : 'text-align:center'
                , type : 'output'
                , renderer : function(obj , row , col , cellData , rowData) {
                    return rowData.dlngStNm;
                }
            }
            ,{
                caption : [g_c_msg.gridCol.dlngDt]
                , ref : 'dlngDt'
                , width : '17%'
                , style : 'text-align:center'
                , type : 'output'
                , format : {
                    type :'custom'
                    , callback : function (val){
                        let d = moment(new Date(Number(val)));
                        return d.format('YYYY-MM-DD HH:mm:ss');
                    }
                }
            }
        ];
    }

    let modalPwInitGridColumns = function(){
        return [
            {
                caption : [g_c_msg.gridCol.applyDt]
                , ref : 'insertDt'
                , width : '25%'
                , style : 'text-align:center'
                , type : 'output'
                , format : {
                    type :'custom'
                    , callback : function (val){
                        let d = moment(new Date(Number(val)));
                        return d.format('YYYY-MM-DD HH:mm:ss');
                    }
                }
            }
            , {
                caption : [g_c_msg.gridCol.id]
                , ref : 'requstLoginId'
                , width : '20%'
                , style : 'text-align:center'
                , type : 'output'
            }
            , {
                caption : [g_c_msg.gridCol.user + ' ' + g_c_msg.gridCol.dept + '/' + g_c_msg.gridCol.empNm]
                , ref : 'cmpnyNm'
                , width : '30%'
                , style : 'text-align:center'
                , type : 'output'
                , renderer : function(obj , row , col , cellData , rowData) {
                    return rowData.requstDeptNm + ' / ' + rowData.requstEmpNm;
                }
            }
            , {
                caption : [g_c_msg.gridCol.userEmail]
                , ref : 'email1'
                , width : '25%'
                , style : 'text-align:center'
                , type : 'output'
            }
        ];
    }


    let getTempPw = function(str, length, type){
        let pawd = '';
        let n = str.length;
        for (let i = 0; i < length; i++) {
            let idx = Math.floor(Math.random() * n);
            pawd += str.charAt(idx);

            if( type ) {   // 최총 비밀번호 생성 시 랜덤으로 자리 재배열
                str = str.substr(0, idx) + str.substr(idx+1);
                n = str.length;
            }
        }
        return pawd;
    }

    // 임시 비밀번호 랜덤생성 btn
    p.fnClickPwRandomBtn = function() {
        let length = 8;
        let minLength = 1;
        let str1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let str2 = '0123456789';
        let str3 = '~․!@#$%^&*()_-+=[]{}|\\;:\'“<>,.?/';

        let tempPw = getTempPw(str1.toLowerCase(), minLength);
        tempPw += getTempPw(str1, minLength);
        tempPw += getTempPw(str2, minLength);
        tempPw += getTempPw(str3, minLength);
        tempPw += getTempPw(str1 + str2 + str3 , 4);
        tempPw = getTempPw(tempPw, length, 'LAST');
        SBUxMethod.set('input_tempPw', tempPw);
    }

    p.fnPagingPwInitGrid = function () {
        getPwInitList();
    }

    p.pwInitGridAfterRefresh = function(){
        p.pwInitData.forEach(function (ele, i){
            p.pwInitGrid.setCellDisabled(i+1, 0, i+1, 0, ele.dlngSt === '900', false);
        })
    }

    p.fnClickChkPwInitBtn = function () {
        let chkList = p.pwInitGrid.getCheckedRowData(0);
        if(chkList.length <= 0){
            alert(g_msg.alertMsgInitListSelect);
            return;
        }
        SBUxMethod.openModal('modal_pwInit');
    }

    p.fnCallbackModalPwInit = function(){
        let chkList = p.pwInitGrid.getCheckedRowData(0);
        p.modalPwInitData = [];
        chkList.forEach(function(ele){
            p.modalPwInitData.push($.extend(true, {}, ele.data));
        })

        if(!p.modalPwInitGrid){
            p.modalPwInitGrid = sbuxComponent.createGrid( 'modalPwInitGridArea', 'pwIninMgt.modalPwInitGrid','pwIninMgt.modalPwInitData', modalPwInitGridColumns(), false);
        }else{
            p.modalPwInitGrid.refresh();
        }

        $('#tmpPwTrArea').show();
        SBUxMethod.set('radio_pwInitMth', 'case01');
        SBUxMethod.set('input_tempPw', '');
    }

    p.fnChangeBeginDd = function (val) {
        let mBegin = moment(SBUxMethod.get('picker_beginDd'));
        let mEnd = moment(SBUxMethod.get('picker_endDd'));
        //g_mBeginDd = mBegin.format('YYYY-MM-DD');
        if(mBegin.isAfter(mEnd)){
            SBUxMethod.set('picker_endDd', mBegin.format('YYYYMMDD'));
            //g_mEndDd = mEnd.format('YYYY-MM-DD');
        }
    }

    p.fnChangeEndDd = function (val) {
        let mBegin = moment(SBUxMethod.get('picker_beginDd'));
        let mEnd = moment(SBUxMethod.get('picker_endDd'));
        //g_mEndDd = mEnd.format('YYYY-MM-DD');
        if(mEnd.isBefore(mBegin)){
            SBUxMethod.set('picker_beginDd', mEnd.format('YYYYMMDD'));
            //g_mBeginDd = mEnd.format('YYYYMMDD');
        }
    }

    // 검색 버튼
    p.fnClickSchBtn = function (){
        let beginDate = SBUxMethod.get('picker_beginDd');
        let endDate = SBUxMethod.get('picker_endDd');
        if( !beginDate || !endDate ) {
            alert(g_msg.alertMsgSchDateSelect);
            return;
        }
        getPwInitList();
    }

    p.fnChangePwInitMth = function (val) {
        if( val === 'case01' ){
            $('#tmpPwTrArea').show();
        }else{
            $('#tmpPwTrArea').hide();
        }
    }

    p.fnClickPwInitBtn = function () {
        let girdData = p.modalPwInitGrid.getGridDataAll();
        let histNoList = [];
        girdData.forEach(function(ele){
            histNoList.push(ele.histNo);
        })

        let method = SBUxMethod.get('radio_pwInitMth');
        if(!method){
            alert(g_msg.alertMsgSchDateSelect);
            return;
        }

        let newPw = SBUxMethod.get('input_tempPw');
        if(method === 'case01'){
            if(!newPw){
                alert(g_msg.alertMsgtempPwRequired);
                return;
            }
        }

        let param = {};
        param.histNoList = histNoList;
        param.method = method;
        if(method === 'case01'){
            param.newPw = newPw;
        }
        setPwInit(param);
        //console.log('초기화 param > ', param);
    }

    return p;
})();