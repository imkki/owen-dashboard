var sample1 = (function(){
	let o = {};
	let text;
	let cnt = 0;

	o.init = function(globalOpt){
		text = globalOpt.text;
		this.render();
		console.log(">>> init");
	}

	o.render = function(){
		$("#textval").text(text);
	}

	var increaseCnt = function(num){
		cnt += num;
		$("#counter").text(cnt);
		console.log("[increaseCnt] cnt:"+ cnt);
	}

	o.clickIncrease = function(){
		increaseCnt(1);
		console.log("[clickIncrease] cnt:"+ cnt);
	}
	return o;
})();