var authorMgtEx = (function(){
	let at = {};

	at.sb_tabAuthor = [];
	at.sb_menuList = [	// @TODO :: 임시
		/*{ text : "시스템설정", value : "" },
		{ text : "인사관리", value : "Y" }*/
	];

	at.sb_cmpnyList = [];
	at.sb_authzGbList = [	// @TODO :: 다국어 적용하기
		{ text : "일반", value : "USER" },
		{ text : "관리자", value : "ADMIN" }
	];

	at.sb_baseApplcYn = [	// @TODO :: 다국어 적용하기
		{ text : "기본", value : "Y" },
		{ text : "선택", value : "N" }
	];

	at.sb_useYn = [
		{ text : message.springMsg.useY, value : "Y", checked : "checked" },
		{ text : message.springMsg.useN, value : "N" }
	];

	at.sb_deptList = [];	// 사원추가 모달 트리
	at.sb_autoDeptList = [];

	at.authorGrid;
	at.authorGridProps = {};
	at.authorGridData = [];

	at.empGrid;
	at.empGridProps = {};
	at.empGridData = [];

	at.menuGrid;
	at.menuSBGridProps = {};
	at.menuGridData = [];

	at.modalDeptEmpGrid;
	at.modalDeptEmpSBGridProps = {};
	at.modalDeptEmpGridData = [];

	at.modalEmpGrid;
	at.modalEmpSBGridProps = {};
	at.modalEmpGridData = [];

	let isMaster = false;	// true : MASTER, false : ADMIN
	let g_msg;
	let g_c_msg = message.springMsg;	// 공통 properties msg
	let g_selAuthzGrpId;	// 권한그룹 추가/수정 구분
	let g_selAuthorObj = {};		// 권한그룹 그리드에서 선택한 row (사원연결, 메뉴권한 저장 시 필요)

	at.init = function(globalOpt){
		g_msg = globalOpt.springMsg;

		let g_empInfo = ocb.cmm.getMyEmpInfo();	// emp 정보 조회
		isMaster = g_empInfo.master;

		at.sb_tabAuthor.push({ "id" : "0", "pid" : "-1", "order" : "1", "text" : g_msg.tab.emp, "targetid" : "empMapping" });
		at.sb_tabAuthor.push({ "id" : "1", "pid" : "-1", "order" : "2", "text" : g_msg.tab.menu, "targetid" : "menuAuthor" });
		SBUxMethod.refresh('tab_author');

		$('#authorMappingArea').css('visibility', 'hidden');

		renderComp(this);
		initDataLoad(this);
	};

	let renderComp = function(obj){
		createAuthorGrid();			// 권한 목록 그리드
		createEmpGrid();
		document.querySelector('#menuGridArea').style.height = 'calc(100vh - 345px)';
		at.authorGrid.resize();
	};

	let initDataLoad = function(obj){
		let param = {};
		getAuthorityList(param);

		at.sb_cmpnyList = ocb.cmm.getMyCmpnyList();
		if(isMaster){
			at.sb_cmpnyList.splice(0, 1);	// idx : 0 (그룹정보) 그룹은 제외
			at.sb_authzGbList.push({ text : "마스터", value : "MASTER" });
			SBUxMethod.refresh('radio_authzGb');
		}
		SBUxMethod.refresh('select_cmpny');

		at.sb_menuList = [];
	};

	// [API] 권한그룹 목록 조회
	let getAuthorityList = function (param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			at.authorGridData = res.data;
			at.authorGrid.refresh();
		}, function(res){
			alert('권한 목록을 조회하는데 실패했습니다.');
		});
	}

	// [API] 권한그룹 추가/수정
	let setAuthorityInfo = function (param){
		let type = g_selAuthzGrpId === '' ? '추가' : '수정';
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/info/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			getAuthorityList({});
			alert('권한그룹을 ' + type + '하였습니다.');
			SBUxMethod.closeModal('modal_authorAdd')
		}, function(res){
			alert('권한그룹을 ' + type + '하는데 실패하였습니다.');
		});
	}

	// [API] 권한그룹 삭제
	let removeAuthorityInfo = function (param){

		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/info/remove', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			getAuthorityList({});
			alert('삭제하였습니다.');
			SBUxMethod.closeModal('modal_authorAdd')
		}, function(res){
			alert('삭제하는데 실패하였습니다.');
		});
	}

	// [API] 사원연결 목록 조회
	let getConnectEmployeeList = function (param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/connect/employee/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			//console.log("res.data >>> " , res.data);
			at.empGridData = res.data;// res.data;
			at.empGrid.refresh();
		}, function(res){
			alert('사원 목록을 조회하는데 실패했습니다.');
		});
	}

	// [API] 사원연결 추가
	let setConnectEmployeeList = function (param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/connect/employee/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			let param = {};
			param.cmpnyId = g_selAuthorObj.cmpnyId;
			param.authzGrpId = g_selAuthorObj.authzGrpId;
			getConnectEmployeeList(param);
			alert('사원을 추가하였습니다.');
		}, function(res){
			alert('사원을 추가하는데 실패하였습니다.' );
		});
	}

	// @TODO :: 공통으로 빼기
	// [API] 부서 조회 -> 사원추가 modal
	let getDeptList2 = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			at.sb_autoDeptList = res.data;
			SBUxMethod.refresh('input_mSchDept');
			at.sb_deptList = res.data;
			at.sb_deptList.unshift({ "id" : 'ROOT', "pid" : "-1", "order" : "0", "text" : g_selAuthorObj.cmpnyNm });	// 최상위 -> 회사
			SBUxMethod.refresh('tree_dept');
		}, function(res){
			alert("부서목록을 조회하는데 실패하였습니다.");
		});
	}

	// [API] 부서 조회 -> 사원추가 modal
	let getDeptList = function (param, fnSucCallback, fnErrCallback) {
		param.useYn = 'Y';	// 사용하는 메뉴만 조회
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			at.sb_autoDeptList = res.data;
			SBUxMethod.refresh('input_mSchDept');
			at.sb_deptList = res.data;
			at.sb_deptList.unshift({ "id" : 'ROOT', "pid" : "-1", "order" : "0", "text" : g_selAuthorObj.cmpnyNm });	// 최상위 -> 회사
			SBUxMethod.refresh('tree_dept');
			if(fnSucCallback){
				fnSucCallback.call(this, res);
			}
		}, function(res){
			alert("부서목록을 조회하는데 실패하였습니다.");
			/*if(fnErrCallback){
				fnErrCallback.call(this, res);
			}*/
		});
	}

	// @TODO :: 공통으로 빼기
	// [API] 부서원 목록 조회
	let getDeptEmpList = function(param){
		let deptId = param.id;
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/employee/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			res.data.forEach(function (ele) {
				let empNm = ele.empVO ? ele.empVO.empNm : '';
				let id = ele.empLoginVO ? ele.empLoginVO.loginId : '';
				ele.empNmId = empNm + '(' + id + ')'; 	// @TODO :: 그리드 컬럼 ref 수정가능하면 삭제하기
			})
			at.modalDeptEmpGridData = res.data;
			at.modalDeptEmpGrid.refresh();
		}, function(res){
			alert("부서원목록을 조회하는데 실패하였습니다.");
		});
	}

	// [API] 권한 사원 연결 삭제
	let removeConnectEmployeeList = function (param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/connect/employee/remove', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			let param = {};
			param.cmpnyId = g_selAuthorObj.cmpnyId;
			param.authzGrpId = g_selAuthorObj.authzGrpId;
			getConnectEmployeeList(param); // 사원 그리드 다시 로드
			alert('삭제하였습니다.');
		}, function(res){
			alert('선택한 사원을 삭제하는데 실패하였습니다.');
		});
	}

	// /rest/menu/main/left/list
	// [API] 메뉴 리스트 조회
	let getMenuList = function (param, fnSucCallback, fnErrCallback) {
		param.useYn = 'Y';	// 사용하는 메뉴만 조회
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/connect/menu/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if(fnSucCallback){
				fnSucCallback.call(this, res);
			}
		}, function(res){
			if(fnErrCallback){
				fnErrCallback.call(this, res);
			}
		});
	}

	let getMenuSelectboxData = function (param) {
		getMenuList(param, function(res){
			console.log('selectbox 리스트 >> ', res.data);
			at.sb_menuList = [];
			at.sb_menuList = res.data.filter(function (ele) {
				return ele.pid === 'ROOT';
			})
			SBUxMethod.refresh('select_menu');
			if( at.sb_menuList.length > 0 ) {
				at.menuGridData = res.data.filter(function (ele) {
					return ele.pid === at.sb_menuList[0].id;
				});
			}else{
				at.menuGridData = [];
			}
			at.menuGrid.refresh();
		}, function(res){
			alert('해당 권한그룹의 메뉴 목록을 가져오는데 실패하였습니다.1');
		});
	}

	let getMenuGridData = function (param) {
		/*at.menuGridData = [];
		at.menuGridData.push({ text : '로그인관리', menuPhase : 1, id : 'M_AS1100' });
		at.menuGridData.push({ text : '접속허용IP관리', menuPhase : 2, id : 'M_AS1300' });
		at.menuGridData.push({ text : '로그인기록', menuPhase : 2, id : 'M_AS1400' });
		at.menuGridData.push({ text : '비밀번호초기화관리', menuPhase : 2, id : 'M_AS1500' });
		at.menuGridData.push({ text : '메뉴관리', menuPhase : 1, id : 'M_AS1600', authzCd : 'A' });
		at.menuGrid.refresh();
		at.menuGridData.forEach(function (ele) {		// @TODO :: 다른 방법 찾으면 수정하기
			ele.sb_tree_checked = !!ele.authzCd;
		});
		at.menuGrid.refresh();*/

		getMenuList(param, function(res){
			console.log('메뉴 그리드 리스트11 >> ', res.data);
			at.menuGridData = res.data;
			at.menuGrid.refresh();
			at.menuGridData.forEach(function (ele) {		// @TODO :: 다른 방법 찾으면 수정하기
				ele.sb_tree_checked = !!ele.authzCd;
			});
			at.menuGrid.refresh();
		}, function(res){
			alert('해당 권한그룹의 메뉴권한 목록을 가져오는데 실패하였습니다.');
		});

		/*ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/connect/menu/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			console.log('메뉴 그리드 리스트 >> ', res.data.menuList);
			at.menuGridData = res.data.menuList;
			at.menuGrid.refresh();
			at.menuGridData.forEach(function (ele) {		// @TODO :: 다른 방법 찾으면 수정하기
				ele.sb_tree_checked = !!ele.authzCd;
			});
			at.menuGrid.refresh();
		}, function(res){
			alert('해당 권한그룹의 메뉴권한 목록을 가져오는데 실패하였습니다.');
		});*/
	}

	let setMenuAuthorList = function (param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/authority/manage/connect/menu/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			//getConnectEmployeeList(); // 사원 그리드 다시 로드
			alert('메뉴권한 정보를 저장하였습니다.');
		}, function(res){
			alert('메뉴권한 정보를 저장하는데 실패하였습니다.');
		});
	}


	// [API] 메뉴 리스트 조회 // @TODO :: 나중에 삭제
	let getGridMenuList = function(param){
		let type = param.id ? 'SELECT' : 'GRID';
		console.log("@@@@@" , param.id ? '그리드 목록' : 'selectbox ');
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/menu/main/left/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if(type === 'SELECT'){
				at.sb_menuList = [];
				at.sb_menuList = res.data.filter(function (ele) {
					return ele.pid === 'ROOT';
				})
				SBUxMethod.refresh('select_menu');

				if( at.sb_menuList.length > 0 ) {
					at.menuGridData = res.data.filter(function (ele) {
						return ele.pid === at.sb_menuList[0].id;
					});
				}
			}else{
				at.menuGridData = res.data;
			}
			at.menuGrid.refresh();
		}, function(res){
			alert('해당 권한그룹의 메뉴 목록을 가져오는데 실패하였습니다.');
		});
	}

	let createAuthorGrid = function(){
		at.authorGridProps.parentid = 'authorGridArea';
		at.authorGridProps.id = 'authorMgtEx.authorGrid';
		at.authorGridProps.jsonref = 'authorMgtEx.authorGridData';
		at.authorGridProps.allowuserresize = false;
		at.authorGridProps.rowheight = '40';
		at.authorGridProps.fixedrowheight = '40';
		at.authorGridProps.emptyrecords = "데이터가 존재하지 않습니다.";
		at.authorGridProps.columns = authorGridColumns();
		at.authorGrid = _SBGrid.create(at.authorGridProps);

		at.authorGrid.bind('click', 'authorMgtEx.fnRowClickAuthorGrid');
		at.authorGrid.bind('dblclick', 'authorMgtEx.fnRowDbClickAuthorGrid');
	};

	let createEmpGrid = function(){
		at.empGridProps.parentid = 'empGridArea';
		at.empGridProps.id = 'authorMgtEx.empGrid';
		at.empGridProps.jsonref = 'authorMgtEx.empGridData';
		at.empGridProps.allowuserresize = false;
		at.empGridProps.rowheight = '40';
		at.empGridProps.fixedrowheight = '40';
		at.empGridProps.emptyrecords = "데이터가 존재하지 않습니다.";
		at.empGridProps.columns = empGridColumns();
		at.empGrid = _SBGrid.create(at.empGridProps);
	};

	let createMenuGrid = function(){
		at.menuSBGridProps.parentid = 'menuGridArea';
		at.menuSBGridProps.id = 'authorMgtEx.menuGrid';
		at.menuSBGridProps.jsonref = 'authorMgtEx.menuGridData';
		at.menuSBGridProps.allowuserresize = false;
		at.menuSBGridProps.rowheight = '40';
		at.menuSBGridProps.fixedrowheight = '40';
		at.menuSBGridProps.emptyrecords = "데이터가 존재하지 않습니다.";
		at.menuSBGridProps.tree = { col : 0, levelref : 'menuPhase', open : true, lock : true, openlevel : 0, checkbox : true, checkboxchildrencheck : true };
		at.menuSBGridProps.columns = menuGridColumns();
		at.menuGrid = _SBGrid.create(at.menuSBGridProps);
		//at.menuGrid.bind('afterrefresh','authorMgtEx.fnGridAfterRefresh');
	};
	
	let createModalDeptEmpGrid = function( girdData ){
		at.modalDeptEmpSBGridProps.parentid = 'modalDeptEmpGridArea';
		at.modalDeptEmpSBGridProps.id = 'authorMgtEx.modalDeptEmpGrid';
		at.modalDeptEmpSBGridProps.jsonref = 'authorMgtEx.modalDeptEmpGridData';
		at.modalDeptEmpSBGridProps.allowuserresize = false;
		at.modalDeptEmpSBGridProps.rowheight = '30';
		at.modalDeptEmpSBGridProps.fixedrowheight = '30';
		at.modalDeptEmpSBGridProps.emptyrecords = "데이터가 존재하지 않습니다.";
		at.modalDeptEmpSBGridProps.columns = modalEmpGridColumns();
		at.modalDeptEmpGrid = _SBGrid.create(at.modalDeptEmpSBGridProps);

		at.modalDeptEmpGrid.bind('dblclick','authorMgtEx.fnRowDbClickModalDeptEmpGrid');
	};

	let createModalEmpGrid = function( girdData ){
		at.modalEmpSBGridProps.parentid = 'modalEmpGridArea';
		at.modalEmpSBGridProps.id = 'authorMgtEx.modalEmpGrid';
		at.modalEmpSBGridProps.jsonref = 'authorMgtEx.modalEmpGridData';
		at.modalEmpSBGridProps.allowuserresize = false;
		at.modalEmpSBGridProps.rowheight = '30';
		at.modalEmpSBGridProps.fixedrowheight = '30';
		at.modalEmpSBGridProps.emptyrecords = "데이터가 존재하지 않습니다.";
		at.modalEmpSBGridProps.columns = modalEmpGridColumns();
		at.modalEmpGrid = _SBGrid.create(at.modalEmpSBGridProps);

		at.modalEmpGrid.bind('dblclick','authorMgtEx.fnRowDbClickModalEmpGrid');

		//at.modalDeptEmpGrid.bind('afterrefresh','authorMgtEx.fnGridAfterRefresh');
	};

	let authorGridColumns = function (){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					fixedcellcheckbox : {
						usemode : true	// 전체 체크박스 사용여부
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.cmpnyNm]
				, ref : 'cmpnyNm'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_msg.authorGridCol.authzGrpNm]
				, ref : 'authzGrpNm'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_msg.authorGridCol.authzGb]
				, ref : 'authzGb'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (val){
						if(val === 'MASTER'){	// @TODO: : 임시, 쿼리 수정되면 삭제하기
							return '마스터';
						}else{
							return at.sb_authzGbList.find(function(ele){ return ele.value === val }).text;
						}
					}
				}
			}
			, {
				caption : [g_msg.authorGridCol.baseApplcYn]
				, ref : 'baseApplcYn'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (val){
						return val === 'Y' ? '기본' : '선택';		// @TODO :: 다국어 설정
					}
				}
			}			
			, {
				caption : [g_c_msg.gridCol.useYn]
				, ref : 'useYn'
				, width : '22%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (val){
						return ocb.cmm.formatUseYnText(val);
					}
				}
			}
		];
	}

	let empGridColumns = function(){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					fixedcellcheckbox : {
						usemode : true	// 전체 체크박스 사용여부
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.dept]
				, ref : 'deptNm'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.clsfNm]	// 직위
				, ref : 'clsfNm'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.rspofcNm]	// 직책
				, ref : 'rspofcNm'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.empNm]
				, ref : 'empNm'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
			}
		];
	}

	let menuGridColumns = function(){
		return [
			{
				caption :  [g_c_msg.gridCol.menuNm]
				, ref : 'text'	// menuNm
				, width : '100%'
				, style : 'text-align:center'
				, type : 'output'

			}
			/*, {
				caption : [g_msg.menuGridCol.authzCdList]
				, ref : 'authzGrpIdList'	//
				, width : '60%'
				, style : 'text-align:center'
				, type : 'output'
			}*/
		];
	}

	let modalEmpGridColumns = function(){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '8%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					fixedcellcheckbox : {
						usemode : true
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.dept]
				, ref : 'deptVO'
				, width : '27%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (deptVO){
						return deptVO.text;
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.clsfNm]	// 직위
				, ref : 'clsfNm'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.rspofcNm] // 직책
				, ref : 'rspofcNm'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.empNmId]
				, ref : 'empNmId'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
				/*, format : {
					type :'custom'
					, callback : function (empVO){
						return empVO.empNm;
					}
				}*/
			}
		];
	}

	let setMadalAuthorInfo = function (obj){
		SBUxMethod.set('select_cmpny', obj && obj.cmpnyId ? obj.cmpnyId : at.sb_cmpnyList[0].cmpnyId);
		SBUxMethod.set('input_authzGrpNm', obj && obj.authzGrpNm ? obj.authzGrpNm : '');
		SBUxMethod.set('radio_authzGb', obj && obj.authzGb ? obj.authzGb : '');
		SBUxMethod.set('radio_useYn', obj && obj.useYn ? obj.useYn : 'Y');
		SBUxMethod.set('radio_baseApplcYn', obj && obj.baseApplcYn ? obj.baseApplcYn : 'N');
	}

	// 권한 그룹 상세보기
	at.fnRowDbClickAuthorGrid = function(){
		let nRow = at.authorGrid.getRow();
		if( nRow <= 0 ) { return; }

		SBUxMethod.setModalTitle('modal_authorAdd', '권한그룹 수정');

		let selObj = at.authorGrid.getRowData(nRow,true); // 클릭한 rowData
		g_selAuthzGrpId = selObj.authzGrpId;
		setMadalAuthorInfo(selObj);

		SBUxMethod.attr('select_cmpny', 'disabled', true);
		SBUxMethod.attr('radio_authzGb', 'disabled', true);
		SBUxMethod.attr('radio_baseApplcYn', 'disabled', SBUxMethod.get('radio_useYn') === 'N');
		SBUxMethod.openModal('modal_authorAdd');
		SBUxMethod.show('mbtn_authorRemove');		// 삭제 버튼 show
	}

	at.fnRowClickAuthorGrid = function(){
		let nRow = at.authorGrid.getRow();
		if( nRow <= 0 ) { return; }
		$('#authorMappingArea').css('visibility', 'visible');
		if( !at.empGrid ){
			createEmpGrid();
		}

		let selObj = at.authorGrid.getRowData(nRow,true); // 클릭한 rowData
		g_selAuthorObj = $.extend(true, {}, selObj);

		let param = {};
		param.cmpnyId = selObj.cmpnyId;
		param.authzGrpId = selObj.authzGrpId;
		getConnectEmployeeList(param);	// @TODO :: API 확인 후
	}

	// 권한그룹 추가
	at.fnClickAuthorAddBtn = function (){
		g_selAuthzGrpId = '';
		SBUxMethod.setModalTitle('modal_authorAdd', '권한그룹 추가');
		setMadalAuthorInfo();
		SBUxMethod.attr('select_cmpny', 'disabled', false);
		SBUxMethod.attr('radio_authzGb', 'disabled', false);
		SBUxMethod.openModal('modal_authorAdd');
		SBUxMethod.hide('mbtn_authorRemove');
	}

	// 권한 선택삭제
	at.fnClickAuthorChkRemove = function (){
		let ckhList = at.authorGrid.getCheckedRowData(0);
		//console.log("ckhList >> " , ckhList);
		if( ckhList.length <= 0 ) {
			alert('삭제할 권한그룹을 선택해 주세요.');
			return false;
		}

		if(confirm("선택한 권한그룹을 삭제하시겠습니까?\r\n(삭제 시, 소속 인원들의 권한은 기본 권한으로 돌아갑니다.)")){
			let removeList = [];
			ckhList.forEach(function(ele){
				let obj = { delYn : 'Y', cmpnyId : ele.data.cmpnyId, authzGrpId : ele.data.authzGrpId };
				removeList.push(obj);
			});
			let param = {};
			param.authzList = removeList;
			removeAuthorityInfo(param);
		}
	}

	// modal 사용여부 selectbox change
	at.fnChangeUseYn = function (val){
		// 미사용일 경우 기본부여 여부 항목 disabled 처리
		SBUxMethod.attr('radio_baseApplcYn', 'disabled', val === 'N');
	}

	// tab 변경 시 Grid Create
	at.fnTabClick = function (){
		let tagetTab = SBUxMethod.get('tab_author');
		if( tagetTab === 'empMapping' ){
			//if(!at.empGrid){
				createEmpGrid();		// 사원 목록 그리드
			/*} else {
				at.em
				pGrid.refresh();
			}*/
		}else{
			//if(!at.menuGrid){
				createMenuGrid();		// 메뉴 권한 그리드 생성
			/*}else{
				at.menuGrid.refresh();
			}*/
			/*let nRow = at.authorGrid.getRow();
			let obj = at.authorGrid.getRowData(nRow,true);*/
			let param = {};
			param.cmpnyId = g_selAuthorObj.cmpnyId;
			param.authzGb = g_selAuthorObj.authzGb;
			param.authzGrpId = g_selAuthorObj.authzGrpId;
			getMenuSelectboxData(param);
		}
	}

	// 사원추가 Btn 클릭
	at.fnClickEmpAdd = function (){
		SBUxMethod.openModal('modal_empAdd');
	}

	// 사원추가 모달 after open
	at.fnCallbackModalEmpAdd = function (){
		let param = {};
		param.cmpnyId = g_selAuthorObj.cmpnyId;
		param.useYn = 'Y';
		getDeptList(param);

		at.modalDeptEmpGridData = [];
		at.modalEmpGridData = [];
		createModalDeptEmpGrid();
		createModalEmpGrid();
		/*if(! at.modalDeptEmpGrid  ) { createModalDeptEmpGrid();}
		if(! at.modalEmpGrid  ) { createModalEmpGrid();}*/
	}

	at.fnRowDbClickModalDeptEmpGrid = function (){
		let nRow = at.modalDeptEmpGrid.getRow();
		let obj = at.modalDeptEmpGrid.getRowData(nRow,true);
		//obj.chkYn = false;

		let chkObj = at.modalEmpGridData.find(function(f){	// 이미 추가된 사원인지 check
			return f.empId === obj.empId;
		});

		if(chkObj){	// 이미 추가되어 있으면 alert
			//alert('\'' + chkObj.empNm + '(' + chkObj.loginId +')' + '\'' + g_msg.alertMsgExistEmpSuffix);
			alert('\'' + chkObj.empNmId + '\'' + '는(은) 이미 선택한 사원입니다.');
			return;
		}

		// 선택 사원 목록에 추가
		at.modalEmpGridData.push($.extend(true, {}, obj));
		at.modalEmpGrid.refresh();
	}

	at.fnRowDbClickModalEmpGrid = function (){
		let nRow = at.modalEmpGrid.getRow();
		let obj = at.modalEmpGrid.getRowData(nRow,true);

		//at.modalEmpGridData.splice(nRow, 1);
		let filterList = at.modalEmpGridData.filter(function(f){	// 이미 추가된 사원인지 check
			return f.empId !== obj.empId;
		});
		at.modalEmpGridData = filterList;
		at.modalEmpGrid.refresh();
	}

	// 사원추가 Modal - 검색 버튼
	at.fnClickModalSearchBtn = function (){
		let deptNm = SBUxMethod.get('input_mSchDept');
		let empNm = SBUxMethod.get('input_mSchEmp');

		let param = {};
		param.cmpnyId = g_selAuthorObj.cmpnyId;
		param.useYn = 'Y';
		param.text = deptNm;
		getDeptList(param, function (res){
			let obj = at.sb_deptList.find(function (ele) {
				return ele.text === deptNm;
			});
			if( obj ){
				SBUxMethod.set('tree_dept', obj.id, 'expand');
				console.log('있다!');
				let empParam = {};
				empParam.cmpnyId = obj.cmpnyId;
				empParam.id = obj.id;
				empParam.empNm = empNm;
				getDeptEmpList(empParam);
			}else{
				at.modalEmpGridData = [];
				at.modalEmpGrid.refresh();
			}
		});	// 부서원 조회
	}

	at.fnClickTreeDeptList = function(obj){
		if(obj.id !== 'ROOT') {
			let param = {};
			param.cmpnyId = obj.attrObj.cmpnyId;
			param.id = obj.attrObj.id;	// id -> deptId
			getDeptEmpList(param);	// 부서원 조회
		}
	};

	// ∨
	at.fnClickGridDataMoveDown = function (){
		let ckhList = at.modalDeptEmpGrid.getCheckedRowData(0);
		let dupList = [];
		console.log('ckhList>' , ckhList);

		ckhList.forEach(function(ele, i){
			// ele.chkYn = false;
			let obj = ele.data;
			obj.chkYn = false;

			let chkObj = at.modalEmpGridData.find(function(f){	// 이미 추가된 사원인지 check
				return f.empId === obj.empId;
			});

			if(chkObj){
				dupList.push($.extend(true, {}, chkObj));
			}else{
				at.modalEmpGridData.push($.extend(true, {}, obj));
			}
		});

		if(dupList.length > 0) {
			let msg = "";
			let str = ', ';
			dupList.forEach(function(ele, i){
				if( i === dupList.length-1 ) { str = ''; }
				msg += '\'' + ele.empNmId + '\'' + str;
			});
			alert(msg + '는(은) 이미 선택한 사원입니다.');
		}

		at.modalEmpGrid.refresh();
	}

	at.fnClickGridDataMoveUp = function (){
		let ckhList = at.modalEmpGrid.getCheckedRowData(0);
		let remainList = [];
		at.modalEmpGridData.forEach(function(ele, i){
			let removeObj = ckhList.find(function(f){
				return ele.empId === f.data.empId;
			});
			if( !removeObj ) { remainList.push($.extend(true, {}, ele)) }//{ dp.sb_modalEmpGridData.splice(i, 1); }	// 선택된 사원목록에서 삭제
		});

		at.modalEmpGridData = remainList;
		at.modalEmpGrid.refresh();
	}

	// 사원연결 탭 검색 버튼
	at.fnClickEmpSearchBtn = function (){
		let empNm = SBUxMethod.get('input_schEmp');
		/*if(!empNm) {
			alert('검색할 이름을 입력해 주세요.');
			return;
		}*/
		let param = {};
		param.cmpnyId = g_selAuthorObj.cmpnyId;
		param.authzGrpId = g_selAuthorObj.authzGrpId;
		param.empNm = empNm ? empNm : '';
		console.log('param> >> ' , param );
		getConnectEmployeeList(param);
	}

	at.fnClickEmpSaveBtn = function (){
		// 저장 로직 추가해야함
		let addEmpList = at.modalEmpGrid.getGridDataAll();
		if( addEmpList.length <=0 ) {
			alert('추가할 사원을 선택해 주세요.');
			return;
		}

		let param = {};
		param.authzGrpId = g_selAuthorObj.authzGrpId;
		param.authzGrpEmpMapngList = addEmpList;

		console.log('추가할 사원들 param >>>> ', param);
		setConnectEmployeeList(param);
		SBUxMethod.closeModal('modal_empAdd');
	}

	// 사원 선택삭제
	at.fnClickEmpChkRemove = function (){
		let ckhList = at.empGrid.getCheckedRowData(0);
		//console.log("ckhList >> " , ckhList);
		if( ckhList.length <= 0 ) {
			alert('삭제할 사원을 선택해 주세요.');
			return false;
		}

		if(confirm("선택한 사원을 삭제하시겠습니까?")){
			let removeList = [];
			ckhList.forEach(function(ele){
				let obj = $.extend(true, {}, ele.data);
				obj.cmpnyId = g_selAuthorObj.cmpnyId;
				obj.authzGrpId = g_selAuthorObj.authzGrpId;
				removeList.push(obj);
			})

			let param = {};
			param.authzGrpEmpMapngList = removeList;
			console.log('삭제할 사원 > ', param);
			removeConnectEmployeeList(param);
		}
	}

	// 메뉴권한 탭 selectbox change
	at.fnChangeMenuList = function (val){
		let param = {};
		param.id = val;
		param.authzGb = g_selAuthorObj.authzGb;
		console.log('메뉴권한 param  >> ' ,  param);
		getMenuGridData(param);
	}

	at.fnClickMenuAuthorSaveBtn = function (){
		let gridData = at.menuGrid.getGridDataAll();
		let addList = gridData.filter(function(ele){
			return ele.sb_tree_checked;
		});

		addList.forEach(function (ele) {
			let menuMapngList = [];
			menuMapngList.push({ cmpnyId : '0003', authzGrpId : 'GRP_001', authzCd : ele.id.split('_')[1] + 'A', menuId : ele.id });
			ele.cmpnyId = '0003'; //g_selAuthorObj.cmpnyId;
			ele.authzGrpId = 'GRP_001'; //g_selAuthorObj.authzGrpId;
			ele.authzCd = ele.id.split('_')[1] + 'A';	// 임시값
			ele.authzMapngList = menuMapngList;

		})

		//console.log('addList > ', addList);
		let param = {};
		param.menuVOList = addList;
		//console.log('param > ', param);
		setMenuAuthorList(param);
	}

	// Modal 권한그룹 적용회사 Change
	at.fnChangeApplcCmpny = function (){
	}

	// Modal 권한그룹 Save
	at.fnClickAuthorSaveBtn = function (){
		let cmpnyId = SBUxMethod.getValue('select_cmpny');
		let authzGrpNm = SBUxMethod.get('input_authzGrpNm');
		let authzGb = SBUxMethod.get('radio_authzGb');
		let useYn = SBUxMethod.get('radio_useYn');
		let baseApplcYn = SBUxMethod.get('radio_baseApplcYn');

		let param = {};
		param.authzGrpId = g_selAuthzGrpId === '' ? 'AAA' : g_selAuthzGrpId;
		param.authzGrpNm = authzGrpNm;
		param.authzGb = authzGb;
		param.cmpnyId = cmpnyId;
		param.baseApplcYn = baseApplcYn;
		param.useYn = useYn;	// TODO:: 설계 반영되면 실제 값으로 변경하기
		param.delYn = 'N';
		param.sortSn = 1;
		console.log('저장 param >>  ' ,param );

		setAuthorityInfo(param);
	}

	// Modal 권한그룹 Remove
	at.fnClickAuthorRemoveBtn = function (){
		if(confirm('해당 권한그룹을 삭제하시겠습니까?\r\n(삭제 시, 소속 인원들의 권한은 기본 권한으로 돌아갑니다.)')){
			let cmpnyId = SBUxMethod.getValue('select_cmpny');
			let param = {};
			param.authzList = [{ delYn : 'Y', cmpnyId : cmpnyId, authzGrpId : g_selAuthzGrpId }];
			removeAuthorityInfo(param);
		}
	}

	return at;
})();