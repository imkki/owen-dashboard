'use strict';
var bssMsMgt = (function () {
    // 전체 스크립트 엄격 모드 구문
    'use strict';

    var r = {};
    r.grpGridProps = {};    // 그룹관리 팝업 도메인 그리드 옵션
    r.grpSelData = [];      // 그룹 셀렉트박스 data
    r.grpGridData = [];     // 그룹관리 팝업 도메인 그리드 data
    r.grpGridId = undefined;              // 그룹관리 팝업 도메인 그리드 객체
    var isCreatedMgtGrid = false;

    r.grpDomnsGridProps = {};
    r.grpDomnsGridData = [];
    r.grpDomnsGridId = undefined;

    r.domnSubGridProps = {};
    r.domnSubGridData = [];
    r.domnSubGridId = undefined;

    r.useYn = [
        { text: "사용", value: "Y" },
        { text: "미사용", value: "N" }
    ]

    /** [START] 세션 유지 기능 */
    var timerId = null;
    var startTimer = function(){
        timerId = setInterval(callSessionNotExpiredUrl, 300000);
        //timerId = setInterval(callSessionNotExpiredUrl, 3000);
    }
    var callSessionNotExpiredUrl = function(){
        var sessionPromise = new Promise(function(resolve, reject){
            ocb.restcli.exchangeAsync('GET', page_context_path + '/web/system/session/doingcheck', null, 'application/json', false,
                function (res) {
                    if (res.code === 'OK') {
                        resolve(res.data ? res.data:[]);
                    }else {
                        reject(res);
                    }
                },
                function (res) {
                    printError('[sessionPromise] err:', res);
                    reject(res);
                });
        });

        sessionPromise
            .then(function(res){
                console.log(res);
            })
            .catch(function(err){
                console.log('ERR:', err ? err:'null');
            })

    }
    /** [END] 세션 유지 기능 */

    r.init = function (globalOpt) {
        renderComp(this);
        attachEvent(this);
        initDataLoad(this);
        startTimer();   // 세션 유지 실행.
    };

    var renderComp = function (obj) {
        createGrpDomnsGrid();
        createDomnSubGrid();
    };

    var attachEvent = function (obj) {
        $("#btn_add_group").click(function(){
            // 그룹관리 '추가' 버튼 클릭
            bindDataGrpViewForm('', '', 'ADD');
            r.grpGridId.clearSelection();
        });

        $("#btn_chk_del_group").click(function(){
            // 그룹관리 '선택삭제' 버튼 클릭
            buttonClickDelGrpByChecked();
        });

        $("#btn_save_group").click(function(){
            // 그룹관리 '저장' 버튼 클릭
            buttonClickSetGroup();
            return false;
        });

        $("#btn_open_modal_group_mgt").click(function(){
            // 그룹관리 '저장' 버튼 클릭
            SBUxMethod.openModal('modal_group_mgt');
            createGroupMgtGrid();
        });

        $("#btn_open_modal_add_subdomain").click(function(){
            // 도메인 정보 > 연결도메인 '도메인추가' 버튼 클릭
            var hostId = ocb.cmm.getValue(SBUxMethod.get('hostId'));
            if(hostId === ''){
                alert('대표도메인을 먼저 선택해 주세요.');
                return false;
            }
            SBUxMethod.openModal('modal_subdomain_add');
            clearDataSubDomnViewForm();
            r.domnSubGridId.clearSelection();
        });

        r.domnSubGridId.bind('dblclick','bssMsMgt.gridDblclickSubDomnRow');

        $("#btn_domain_Add").click(function(){
            // 도메인 '추가' 버튼 클릭
            clearDataDomnBasicViewForm();
            r.grpDomnsGridId.clearSelection();
            r.domnSubGridData = [];
            r.domnSubGridId.rebuild();
        });

        $("#btn_del_domain_chk").click(function(){
            // 도메인 선택 삭제 버튼 클릭
            buttonClickDelDomnByChecked();
        });

        $("#btn_domain_save").click(function(){
            // 도메인 저장 버튼 클릭
            buttonClickSaveDataDomnBasicForm();
        });

        $("#btn_save_subdomn").click(function(){
            // 도메인 저장 버튼 클릭
            buttonClickSaveDataSubDomnForm();
        });

        $("#btn_del_subdomain_chk").click(function(){
            buttonClickDelSubDomnByChecked();
        });

        $("#btn_sync_group_redis").click(function(){
            buttonClickSyncGrpConfigToRedis();
        });

    };

    var initDataLoad = function (obj) {
        getGrpListPromise()
            .then(function(gdata){
                SBUxMethod.set('sel_group', r.grpSelData[0].value);
                var grpVal = SBUxMethod.getValue('sel_group');
                if(ocb.cmm.getValue(grpVal) !== ''){
                    return getGrpDomainListPromise(grpVal);
                }else{
                    return [];
                }
            })
            .then(function(resList){
                r.grpDomnsGridData = resList;
                r.grpDomnsGridId.rebuild();
            })
            .catch(function(err){
                alert(' 그룹 정보 조회 실패 ');
            });
    };

    var parseGrpDatas = function(list){
        var rdata = [];
        if(list && list.length && list.length > 0){
            list.forEach(function(ele){
                rdata.push({ value:ele.svcGrpId , text:ele.svcGrpNm });
            });
        }else{
            rdata = [{ value:'' , text:'N/A' }];
        }
        return rdata;
    }

    var createGrpDomnsGrid = function () {
        r.grpDomnsGridProps.parentid = 'grid_group_domain_area';
        r.grpDomnsGridProps.id = 'bssMsMgt.grpDomnsGridId';
        r.grpDomnsGridProps.jsonref = 'bssMsMgt.grpDomnsGridData';
        r.grpDomnsGridProps.emptyrecords = '데이터가 존재하지 않습니다.';
        r.grpDomnsGridProps.columns = [
            {
                caption: [''],
                ref: 'rowid',
                width: '20%',
                style: 'text-align:center',
                type: 'checkbox'
            },
            {caption: ['대표 도메인'], ref: 'hostDomn', width: '50%', style: 'text-align:center', type: 'output'},
            {caption: ['사용여부'], ref: 'useYn', width: '30%', style: 'text-align:center', type: 'output'}
        ]
        r.grpDomnsGridId = _SBGrid.create(r.grpDomnsGridProps);
        r.grpDomnsGridId.bind('click', 'bssMsMgt.gridRowClickGrpDomns');
    };

    var createDomnSubGrid = function () {
        r.domnSubGridProps.parentid ='grid_domin_sub_area';
        r.domnSubGridProps.id = 'bssMsMgt.domnSubGridId';
        r.domnSubGridProps.jsonref = 'bssMsMgt.domnSubGridData';
        r.domnSubGridProps.emptyrecords = '데이터가 존재하지 않습니다.';
        r.domnSubGridProps.columns = [
            {
                caption: [''],
                ref: 'rowId',
                width: '10%',
                style: 'text-align:center',
                type: 'checkbox',
                typeinfo: {
                    checkedvalue: 'true',
                    uncheckedvalue: 'false',
                    fixedcellcheckbox: {usemode: true, rowindex: 0, deletecaption: true}
                }
            },
            {caption: ['도메인'], ref: 'hostDomn', width: '30%', style: 'text-align:center', type: 'output'},
            {caption: ['비고'], ref: 'rmCn', width: '30%', style: 'text-align:center', type: 'output'},
            {caption: ['정렬순번'], ref: 'sortSn', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['사용여부'], ref: 'useYn', width: '15%', style: 'text-align:center', type: 'output'},
        ]
        r.domnSubGridId = _SBGrid.create(r.domnSubGridProps);
    };

    var createGroupMgtGrid = function () {
        if(isCreatedMgtGrid === true){
            return;
        }
        r.grpGridProps.parentid ='group_mgt_grid_area';
        r.grpGridProps.id = 'bssMsMgt.grpGridId';
        r.grpGridProps.jsonref = 'bssMsMgt.grpGridData';
        r.grpGridProps.emptyrecords = '데이터가 존재하지 않습니다.';
        r.grpGridProps.columns = [
            {
                caption: [''],
                ref: 'rowIndex',
                width: '20%',
                style: 'text-align:center',
                type: 'checkbox'
            },
            {caption: ['그룹ID'], ref: 'svcGrpId', width: '30%', style: 'text-align:center', type: 'output'},
            {caption: ['그룹명'], ref: 'svcGrpNm', width: '50%', style: 'text-align:center', type: 'output'}
        ]
        r.grpGridId = _SBGrid.create(r.grpGridProps);
        r.grpGridId.bind('click', 'bssMsMgt.gridRowClickGrp');
        isCreatedMgtGrid = true;
    };

    var refreshGrpSelectbox = function(gdata){
        r.grpSelData = parseGrpDatas(gdata);
        SBUxMethod.refresh('sel_group')
    }

    var refreshGrpGrid = function(gdata, svcGrpId){
        r.grpGridData = gdata;
        if(isCreatedMgtGrid === true) {
            r.grpGridId.rebuild();
            r.grpGridId.clickRow(searchGrpGridIndex(svcGrpId, r.grpGridData) + 1, true);
        }
    }

    var refreshGrpDomnsGrid = function(gdata, id){
        r.grpDomnsGridData = gdata;
        r.grpDomnsGridId.rebuild();
        if(ocb.cmm.getValue(id) !== '') {
            var selRowIndex = searchGrpDomnsGridIndex(id, r.grpDomnsGridData) + 1;
            r.grpDomnsGridId.clickRow(selRowIndex, true);
        } else {
            if(gdata && gdata.length && gdata.length > 0) {
                r.grpDomnsGridId.clickRow(1, true);
            }
        }
    }

    r.changeGrpSelectBox = function(val){
        console.log('changeGrpSelectBox called:', val, ocb.cmm.getValue(val));
        if(ocb.cmm.getValue(val) === '') {
            return;
        }
        clearDataDomnBasicViewForm();
        r.domnSubGridData = [];
        r.domnSubGridId.rebuild();
        getGrpDomainListPromise(val)
            .catch(function (err) {
                errorHandle(err, '조회 오류가 발생 하였습니다.');
                return false;
            });
    }

    // 그룹관리 그리드 클릭
    r.gridRowClickGrp = function (){
        if(!r.grpGridId) return;
        var rowObj = r.grpGridId.getRowData(r.grpGridId.getRow(),false);
        bindDataGrpViewForm(rowObj.svcGrpId, rowObj.svcGrpNm, 'SET');
    }

    // 그룹 도메인 GRID row 클릭시
    r.gridRowClickGrpDomns = function(){
        if(!r.grpDomnsGridId) return;
        var rowObj = r.grpDomnsGridId.getRowData(r.grpDomnsGridId.getRow(),false);
        if(!rowObj || !rowObj.hostId || rowObj.hostId === ''){
            return;
        }
        Promise.all([getDomainInfoPromise(rowObj.hostId), getDomainSubListPromise(rowObj.hostId)])
            .catch(function (err) {
                errorHandle(err, '정보 조회 중 오류가 발생 하였습니다.');
            });
    }

    r.gridDblclickSubDomnRow = function(){
        var nRow = r.domnSubGridId.getRow();
        var rowObj = r.domnSubGridId.getRowData(nRow, false);
        if(!rowObj) return;
        SBUxMethod.openModal('modal_subdomain_add');
        bindDataSubDomnViewForm(rowObj);
    }
    // 그룹 등록/수정 버튼 클릭.
    var buttonClickSetGroup = function(){
        var actType = ocb.cmm.getValue($("#act_type_group").val());
        var svcGrpId = ocb.cmm.getValue($("#svc_group_id").val()).trim();
        var svcGrpNm = ocb.cmm.getValue($("#svc_group_name").val()).trim();
        if(svcGrpId === ''){
            alert('그룹ID를 입력하세요.');
            return false;
        }
        if(svcGrpNm === ''){
            alert('그룹명을 입력하세요.');
            return false;
        }

        var actNm = '수정';
        var actUrl = '/rest/bss/system/servicegroup/group/set';
        if(actType === 'ADD'){
            actUrl = '/rest/bss/system/servicegroup/group/add';
            actNm = '등록';
        }

        var param = {};
        param.svcGrpId= svcGrpId;
        param.svcGrpNm= svcGrpNm;

        var addGrpPromise = new Promise(function(resolve, reject){
            ocb.restcli.exchangeAsync('POST', page_context_path + actUrl, JSON.stringify(param), 'application/json', true,
                function (res) {
                    if (res.code === 'OK') {
                        resolve(res.data);
                    }else {
                        reject(genError('G1001', errMsgFromApi(res)));
                    }
                },
                function (res) {
                    printError('[addGrpPromise] err:', res);
                    reject(genError('G1002', errMsgFromApi(res)));
                });
        });

        addGrpPromise
            .then(function(res){
                bindDataGrpViewForm('', '', 'ADD');
                return getGrpListPromise(svcGrpId);
            })
            .then(function (gdata) {
                alert(actNm +' 되었습니다. ');
            })
            .catch(function (err) {
                errorHandle(err, actNm +' 처리 중 오류가 발생하였습니다.');
                return false;
            })
    }

    // 그룹관리 '삭제' 버튼 클릭
    var buttonClickDelGrpByChecked = function(){
        var checkedRows = r.grpGridId.getCheckedRowData(0); //.getCheckedRows(0);
        if(!checkedRows || !checkedRows.length || checkedRows.length === 0){
            alert('삭제할 행을 먼저 체크해 주세요.');
            return;
        }
        if(confirm('['+ checkedRows.length +']건을 삭제 하시겠습니까?')){
            if(!confirm('삭제시 복구할 수 없습니다. 그래도 삭제 하시겠습니까?')) {
                return;
            }
        }else{
            return;
        }

        var chkGrpIds = [];
        checkedRows.forEach(function(rowObj){
            chkGrpIds.push(rowObj.data.svcGrpId);
        });

        var param = {};
        param.svcGrpIdList = chkGrpIds;
        var delGrpPromise = new Promise(function(resolve, reject){
            ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/bss/system/servicegroup/group/del', JSON.stringify(param), 'application/json', true,
                function (res) {
                    if (res.code === 'OK') {
                        resolve(res.data);
                    }else {
                        reject(genError('G1001', errMsgFromApi(res)));
                    }
                },
                function (res) {
                    printError('[delGrpPromise] err:', res);
                    reject(genError('G1002', errMsgFromApi(res)));
                });
        });

        delGrpPromise
            .then(function(res){
                return getGrpListPromise();
            })
            .then(function (gdata) {
                alert('삭제 되었습니다.');
            })
            .catch(function (err) {
                console.log('last err catched:', err);
                errorHandle(err, '삭제 처리 중 오류가 발생하였습니다.');
                return false;
            });
    }

    var buttonClickSaveDataDomnBasicForm = function() {
        var actType = ocb.cmm.getValue(SBUxMethod.get('domnActType'));
        var hostId = ocb.cmm.getValue(SBUxMethod.get('hostId'));
        var hostDomn = ocb.cmm.getValue(SBUxMethod.get('hostDomn'));
        var oldHostDomn = ocb.cmm.getValue(SBUxMethod.get('oldHostDomn'));
        var useYn = ocb.cmm.getValue(SBUxMethod.get('domnUseYn'));
        var dbNm = ocb.cmm.getValue(SBUxMethod.get('dbNm'));
        var dbIp = ocb.cmm.getValue(SBUxMethod.get('dbIp'));
        var dbPortNo = ocb.cmm.getValue(SBUxMethod.get('dbPortNo'));
        var dbAccountId = ocb.cmm.getValue(SBUxMethod.get('dbAccountId'));
        var dbAccountPwd = ocb.cmm.getValue(SBUxMethod.get('dbAccountPwd'));
        var minIdle = ocb.cmm.getValue(SBUxMethod.get('minIdle'));
        var maxTotal = ocb.cmm.getValue(SBUxMethod.get('maxTotal'));
        var rmCn = ocb.cmm.getValue(SBUxMethod.get('rmCn'));
        var svcGrpId = ocb.cmm.getValue(SBUxMethod.getValue('sel_group'));

        var actNm = actType === 'ADD' ? '등록' : '수정';
        if (actType !== 'ADD') {
            if (hostId === '') {
                console.error('>> hostId is empty.');
                alert("데이터에 오류가 있습니다. 새로고침후에 다시 시도해 주세요.");
                return false;
            }
            if (oldHostDomn === '') {
                console.error('>> oldHostDomn is empty.');
                alert("데이터에 오류가 있습니다. 새로고침후에 다시 시도해 주세요.");
                return false;
            }
        }

        if (svcGrpId === '') {
            alert("데이터에 오류가 있습니다. 새로고침후에 다시 시도해 주세요.");
            return false;
        }

        if (hostDomn === '') {
            alert("도메인을 입력하세요.");
            return false;
        }

        if (!(useYn === 'Y' || useYn === 'N')) {
            alert("사용여부를 선택해 주세요");
            return false;
        }

        if (dbNm === '') {
            alert("DB명을 입력해 주세요");
            return false;
        }
        if (dbIp === '') {
            alert("DB IP 또는 Host를 입력해 주세요");
            return false;
        }

        if (dbPortNo === '') {
            alert("DB Port를 입력해 주세요");
            return false;
        }

        if (dbAccountId === '') {
            alert("DB 계정을 입력해 주세요");
            return false;
        }

        if (dbAccountPwd === '') {
            alert("DB 비밀번호를 입력해 주세요");
            return false;
        }
        if (minIdle === '') {
            alert("minIdle을 입력해 주세요");
            return false;
        }
        if (maxTotal === '') {
            alert("maxTotal을 입력해 주세요");
            return false;
        }

        var dbPortNoNum = ocb.cmm.getIntValue(dbPortNo, 0);
        var minIdleNum = ocb.cmm.getIntValue(minIdle, 0);
        var maxTotalNum = ocb.cmm.getIntValue(maxTotal, 0);
        if (dbPortNoNum < 1) {
            alert("DB Port를 0보다 큰 숫자로 입력해 주세요");
            return false;
        }
        if (minIdleNum <= 0 || minIdleNum > 50) {
            alert("minIdle을 숫자로 1~50사이의 값을 입력해 주세요");
            return false;
        }
        if (maxTotalNum <= 0 || maxTotalNum > 100) {
            alert("minIdle을 숫자로 1~100사이의 값을 입력해 주세요");
            return false;
        }
        if (minIdleNum > maxTotalNum) {
            alert("minIdle은 maxTotalNum보다 클수 없습니다.");
            return false;
        }
        if (!confirm(actNm + ' 하시겠습니까?')) {
            return false;
        }

        var param = {};
        if (actType !== 'ADD') {
            param.hostId = hostId;
        }
        param.svcGrpId = svcGrpId;
        param.hostDomn = hostDomn;
        param.useYn = useYn;
        param.dbNm = dbNm;
        param.dbIp = dbIp;
        param.dbPortNo = dbPortNoNum;
        param.dbAccountId = dbAccountId;
        param.dbAccountPwd = dbAccountPwd;
        param.dbMinIdle = minIdleNum;
        param.dbMaxTotal = maxTotalNum;
        param.rmCn = rmCn;
        if (actType !== 'ADD') {
            param.oldHostDomn = oldHostDomn;
        }

        var actPromise = undefined;
        if (actType === 'ADD') {
            actPromise = addDomainBasicInfoPromise;
        } else {
            actPromise = setDomainBasicInfoPromise;
        }

        var resHostId = null;
        actPromise(param)
            .catch(function (err) {
                throw genError('G2001', actNm+' 처리에 실패 하였습니다.')
            })
            .then(function (res) {
                if(actType === 'ADD') {
                    if (res && res !== '') {
                        resHostId = res;
                    }
                }else{
                    resHostId = hostId;
                }
                return getGrpDomainListPromise(svcGrpId, resHostId);
            })
            .then(function(res){
                return true;
            })
            .catch(function (err) {
                console.log('last err catched:', err);
                errorHandle(err, '처리 중 오류가 발생하였습니다.');
                return false;
            }).then(function(val){
                if(val === true) {
                    alert(actNm +' 되었습니다.');
                }
            });
    }

    var buttonClickSaveDataSubDomnForm = function(){
        var actType = ocb.cmm.getValue(SBUxMethod.get('subDomnActType'));
        var hostId = ocb.cmm.getValue(SBUxMethod.get('hostId'));
        var subHostDomn = ocb.cmm.getValue(SBUxMethod.get('subHostDomn'));
        var subRmCn = ocb.cmm.getValue(SBUxMethod.get('subRmCn'));
        var subSortSn = ocb.cmm.getValue(SBUxMethod.get('subSortSn'));
        var subUseYn = ocb.cmm.getValue(SBUxMethod.get('subUseYn'));

        var actNm = actType === 'ADD' ? '등록' : '수정';
        if (actType !== 'ADD') {
            if (subHostDomn === '') {
                alert("데이터에 오류가 있습니다. 새로고침후에 다시 시도해 주세요.");
                return false;
            }
        }

        if (hostId === '') {
            alert("데이터에 오류가 있습니다. 새로고침후에 다시 시도해 주세요.");
            return false;
        }

        if(subHostDomn === ''){
            alert("도메인을 입력해 주세요.");
            return false;
        }

        var subSortSnNum = ocb.cmm.getIntValue(subSortSn, 0);
        if(subSortSn === ''){
            alert("정렬순번 값을 입력해 주세요.");
            return false;
        }
        if(subSortSnNum <= 0){
            alert("정렬순번 값이 올바르지 않습니다. 숫자로만 입력해 주세요.");
            return false;
        }
        if(!(subUseYn === 'Y' || subUseYn === 'N')){
            alert("사용여부를 선택해 주세요.");
            return false;
        }

        var paramObj = {};
        paramObj.hostId = hostId;
        paramObj.hostDomn = subHostDomn;
        paramObj.rmCn = subRmCn;
        paramObj.sortSn = subSortSn;
        paramObj.useYn = subUseYn;

        var actPromise = undefined;
        if(actType === 'ADD'){
            actPromise = addDomainSubInfoPromise;
        } else {
            actPromise = setDomainSubInfoPromise;
        }

        actPromise(paramObj)
            .then(function(res){
                return getDomainSubListPromise(hostId);
            })
            .then(function(res){
                if(res && res === true) {
                    clearDataSubDomnViewForm();
                    if(actType !== 'ADD') {
                        SBUxMethod.closeModal('modal_subdomain_add');
                    }
                    alert(actNm + ' 되었습니다.');
                }else{
                    alert(actNm + ' 처리 중 오류가 발생하였습니다.');
                }
            })
            .catch(function(err){
                errorHandle(err, '처리 중 오류가 발생하였습니다.');
            });
    }

    var buttonClickDelDomnByChecked = function(){
        var svcGrpId = ocb.cmm.getValue(SBUxMethod.getValue('sel_group'));
        if (svcGrpId === '') {
            alert("데이터에 오류가 있습니다. 새로고침후에 다시 시도해 주세요.");
            return false;
        }

        var checkedRows = r.grpDomnsGridId.getCheckedRowData(0);
        if(!checkedRows || !checkedRows.length || checkedRows.length === 0){
            alert('삭제할 행을 먼저 체크해 주세요.');
            return;
        }
        if(confirm('['+ checkedRows.length +']건을 삭제 하시겠습니까?')){
            if(!confirm('삭제시 복구할 수 없습니다. 그래도 삭제 하시겠습니까?')) {
                return;
            }
        }else{
            return;
        }

        var chkGrpIds = [];
        checkedRows.forEach(function(rowObj){
            // svcGrpId, hostId
            chkGrpIds.push({svcGrpId: rowObj.data.svcGrpId, hostId: rowObj.data.hostId});
        });

        removeDomainPromise(chkGrpIds)
            .then(function(){
                return getGrpDomainListPromise(svcGrpId);
            })
            .then(function(res){
                alert('삭제 되었습니다.');
            })
            .catch(function(err){
                errorHandle(err, '삭제 처리 중 오류가 발생하였습니다.');
            });
    }

    var buttonClickDelSubDomnByChecked = function(){
        var hostId = ocb.cmm.getValue(SBUxMethod.get('hostId'));
        if (hostId === '') {
            alert("데이터에 오류가 있습니다. 새로고침후에 다시 시도해 주세요.");
            return false;
        }

        var checkedRows = r.domnSubGridId.getCheckedRowData(0);
        if(!checkedRows || !checkedRows.length || checkedRows.length === 0){
            alert('삭제할 행을 먼저 체크해 주세요.');
            return;
        }
        if(confirm('['+ checkedRows.length +']건을 삭제 하시겠습니까?')){
            if(!confirm('삭제시 복구할 수 없습니다. 그래도 삭제 하시겠습니까?')) {
                return;
            }
        }else{
            return;
        }

        var chkGrpIds = [];
        checkedRows.forEach(function(rowObj){
            chkGrpIds.push({hostId: hostId, hostDomn: rowObj.data.hostDomn});
        });

        removeDomainSubInfoPromise(chkGrpIds)
            .then(function(){
                return getDomainSubListPromise(hostId);
            })
            .then(function(res){
                alert('삭제 되었습니다.');
            })
            .catch(function(err){
                errorHandle(err, '삭제 처리 중 오류가 발생하였습니다.');
            });
    }

    var buttonClickSyncGrpConfigToRedis = function(){
        var svcGrpNm = ocb.cmm.getValue(SBUxMethod.getText('sel_group'));
        var svcGrpId = ocb.cmm.getValue(SBUxMethod.getValue('sel_group'));
        if(svcGrpId === ''){
            alert('동기화할 대상의 그룹을 선택해 주세요.');
            return;
        }
        // var gridRowCount = r.grpDomnsGridId.getRows();
        // 데이터가 없는 경우는 redis정보 삭제와 같은 역할을 하므로 갯수 없어도 수행.

        if(!confirm('['+ svcGrpNm +']그룹의 설정정보 전체를 Redis와 동기화 처리 하시겠습니까?')){
            return;
        }

        syncGroupConfigPromise(svcGrpId)
            .then(function(res){
                alert('처리 되었습니다.');
            })
            .catch(function(err){
                errorHandle(err, '처리 중 오류가 발생하였습니다.');
            });
    }

    // 그룹관리 > 그룹정보 상세 데이터 binding
    var bindDataGrpViewForm = function(id, name, actType){
        var actMth = (actType && actType === 'ADD') ? 'ADD':'SET';
        $("#act_type_group").val(actMth);
        $("#svc_group_id").val(id);
        $("#svc_group_name").val(name);
        SBUxMethod.attr('svc_group_id', 'readonly', actMth === 'ADD' ? 'false':'true');
    }

    var bindDataDomnBasicViewForm = function(rowObj){
        if(!rowObj){
            return;
        }
        // $("#hostId").val(rowObj.hostId);
        SBUxMethod.set('domnActType', 'SET');
        SBUxMethod.set('hostId', rowObj.hostId);
        SBUxMethod.set('svcGrpId', rowObj.svcGrpId);
        SBUxMethod.set('hostDomn', rowObj.hostDomn);
        SBUxMethod.set('oldHostDomn', rowObj.hostDomn);
        SBUxMethod.set('domnUseYn', rowObj.useYn);
        SBUxMethod.set('dbNm', rowObj.dbNm);
        SBUxMethod.set('dbIp', rowObj.dbIp);
        SBUxMethod.set('dbPortNo', rowObj.dbPortNo);
        SBUxMethod.set('dbAccountId', rowObj.dbAccountId);
        SBUxMethod.set('dbAccountPwd', rowObj.dbAccountPwd);
        SBUxMethod.set('minIdle', rowObj.dbMinIdle);
        SBUxMethod.set('maxTotal', rowObj.dbMaxTotal);
        SBUxMethod.set('rmCn', rowObj.rmCn);
        // SBUxMethod.attr('svc_group_id', 'readonly', actMth === 'ADD' ? 'false':'true');
    }

    var clearDataDomnBasicViewForm = function(){
        SBUxMethod.set('domnActType', 'ADD');
        SBUxMethod.set('hostId', '');
        SBUxMethod.set('svcGrpId', '');
        SBUxMethod.set('hostDomn', '');
        SBUxMethod.set('oldHostDomn', '');
        SBUxMethod.set('domnUseYn', 'Y');
        SBUxMethod.set('dbNm', '');
        SBUxMethod.set('dbIp', '');
        SBUxMethod.set('dbPortNo', '');
        SBUxMethod.set('dbAccountId', '');
        SBUxMethod.set('dbAccountPwd', '');
        SBUxMethod.set('minIdle', '5');
        SBUxMethod.set('maxTotal', '10');
        SBUxMethod.set('rmCn', '');
        // SBUxMethod.attr('svc_group_id', 'readonly', actMth === 'ADD' ? 'false':'true');
    }

    var clearDataSubDomnViewForm = function(){
        SBUxMethod.set('subDomnActType', 'ADD');
        SBUxMethod.set('subHostDomn', '');
        SBUxMethod.attr('subHostDomn', 'readonly', 'false');
        SBUxMethod.set('subRmCn', '');
        SBUxMethod.set('subUseYn', 'Y');
        SBUxMethod.set('subSortSn', '1000');
    }

    var bindDataSubDomnViewForm = function(obj){
        // SBUxMethod.set('hostId', '');
        // SBUxMethod.set('svcGrpId', '');
        SBUxMethod.set('subDomnActType', 'SET');
        SBUxMethod.set('subHostDomn', obj.hostDomn);
        SBUxMethod.attr('subHostDomn', 'readonly', 'true');
        SBUxMethod.set('subRmCn', obj.rmCn);
        SBUxMethod.set('subUseYn', obj.useYn);
        SBUxMethod.set('subSortSn', obj.sortSn);
    }

    // 그룹 목록 조회 Promise
    var getGrpListPromise = function(svcGrpId){
        return new Promise(function(resolve, reject){
            ocb.restcli.exchangeAsync('GET', page_context_path + '/rest/bss/system/servicegroup/group/list', null,
                'application/json', true,
                function (res) {
                    if (res.code === 'OK') {
                        resolve(res.data ? res.data:[]);
                    }else {
                        reject(genError('G1001', errMsgFromApi(res)));
                    }
                },
                function (res) {
                    printError('[getGrpListPromise] err:', res);
                    reject(genError('G1002', errMsgFromApi(res)));
                });
        }).then(function(gdata){
            refreshGrpGrid(gdata, svcGrpId);
            refreshGrpSelectbox(gdata);
            return gdata;
        });
    }

    // 그룹의 도메인 목록 조회 Promise
    var getGrpDomainListPromise = function(svcGrpId, selectedHostId){
        var param = {svcGrpId: svcGrpId};
        return new Promise(function(resolve, reject){
            ocb.restcli.exchangeAsync('GET', page_context_path + '/rest/bss/system/servicegroup/group/domain/list',
                param, ocb.restcli.contentType.formurlencoded, true,
                function (res) {
                    if (res.code === 'OK') {
                        resolve(res.data ? res.data:[]);
                    }else {
                        reject(genError('G1001', errMsgFromApi(res)));
                    }
                },
                function (res) {
                    printError('[getGrpDomainListPromise] err:', res);
                    reject(genError('G1002', errMsgFromApi(res)));
                });
        }).then(function(res){
            refreshGrpDomnsGrid(res, selectedHostId);
            return res;
        });
    }

    // 그룹의 도메인 기본 정보 조회 Promise
    var getDomainInfoPromise = function(hostId){
        return sendPostJsonPromise({hostId: hostId}, '/rest/bss/system/servicegroup/group/domain/basic/get')
            .then(function(resData){
                bindDataDomnBasicViewForm(resData);
            });
    }

    // 그룹의 도메인 연결도메인 목록 조회 Promise
    var getDomainSubListPromise = function(hostId){
        return sendPostJsonPromise({hostId: hostId}, '/rest/bss/system/servicegroup/group/domain/sub/list')
            .then(function(resObj){
                resObj = resObj ? resObj : [];
                r.domnSubGridData = resObj;
                r.domnSubGridId.rebuild();
                return true;
            });
    }

    // 그룹의 도메인 기본정보 등록 Promise
    var addDomainBasicInfoPromise = function(param){
        return sendPostJsonPromise(param, '/rest/bss/system/servicegroup/group/domain/add');
    }

    // 그룹의 도메인 기본정보 수정 Promise
    var setDomainBasicInfoPromise = function(param){
        return sendPostJsonPromise(param, '/rest/bss/system/servicegroup/group/domain/set');
    }

    // 그룹의 도메인 기본정보 삭제 Promise
    var removeDomainBasicInfoPromise = function(paramList){
        return sendPostJsonPromise(paramList, '/rest/bss/system/servicegroup/group/domain/del');
    }

    var removeDomainPromise = function(paramList){
        return sendPostJsonPromise(paramList, '/rest/bss/system/servicegroup/group/domain/del');
    }

    // 그룹의 도메인 연결도메인 등록 Promise
    var addDomainSubInfoPromise = function(param){
        return sendPostJsonPromise(param, '/rest/bss/system/servicegroup/group/domain/sub/add');
    }

    // 그룹의 도메인 연결도메인 수정 Promise
    var setDomainSubInfoPromise = function(param){
        return sendPostJsonPromise(param, '/rest/bss/system/servicegroup/group/domain/sub/set');
    }

    // 그룹의 도메인 연결도메인 삭제 Promise
    var removeDomainSubInfoPromise = function(paramList){
        return sendPostJsonPromise(paramList, '/rest/bss/system/servicegroup/group/domain/sub/del');
    }

    var syncGroupConfigPromise = function(svcGrpId){
        var paramObj = {svcGrpId: svcGrpId};
        return sendPostJsonPromise(paramObj, '/rest/bss/system/service/domain/config/redis/group/sync');
    }

    var sendPostJsonPromise = function(data, url){
        return new Promise(function(resolve, reject){
            ocb.restcli.exchangeAsync('POST', page_context_path + url,
                JSON.stringify(data), ocb.restcli.contentType.json, true,
                function (res) {
                    if (res.code === 'OK') {
                        resolve(res.data ? res.data:null);
                    }else {
                        reject(genError('G1001', errMsgFromApi(res)));
                    }
                },
                function (res) {
                    printError('[sendPostJsonPromise] err:', res);
                    reject(genError('G1002', errMsgFromApi(res)));
                });
        });
    }

    // Util function
    var searchGrpGridIndex = function(svcGrpId, dataList){
        if(!dataList || !dataList.length || dataList.length === 0){
            return 0;
        }

        if(!svcGrpId || svcGrpId === ''){
            return 0;
        }

        let idxList = [];
        dataList.filter(function(ele, index){
            if( ele.svcGrpId && ele.svcGrpId === svcGrpId ){
                idxList.push(index);
                return true;
            }
        });
        if(idxList.length === 0){
            idxList.push(0);
        }
        return idxList[0];
    }

    var searchGrpDomnsGridIndex = function(id, dataList){
        if(!dataList || !dataList.length || dataList.length === 0){
            return 0;
        }

        if(!id || id === ''){
            return 0;
        }

        let idxList = [];
        dataList.filter(function(ele, index){
            if( ele.hostId && ele.hostId === id ){
                idxList.push(index);
                return true;
            }
        });
        if(idxList.length === 0){
            idxList.push(0);
        }
        return idxList[0];
    }

    var genError = function(errNm, errMsg){
        var err = new Error();
        err.name = errNm;
        err.message = errMsg;
        return err;
    }

    var errMsgFromApi = function(err){
        return '['+ err.code +'] '+ err.message;
    }
    var errorHandle = function(err, defMsg){
        if(err && err.message){
            alert(err.message);
        }else {
            alert(defMsg);
        }
    }

    var getErrMessage = function(err, defMsg){
        if(!err || ocb.cmm.getValue(err.code) === '' || ocb.cmm.getValue(err.message) === ''){
            return defMsg
        }
        return '['+ err.code +'] '+ err.message;
    }

    var alert = function(msg){
        var data={
            title : '알림', text : msg,
            mode : 'info', time : 800, placement: 'middle-center', is_fixed: false,fade_in_speed:1, fade_out_speed: 300};
        SBUxMethod.openAlert(data);
    }

    return r;
})();