let G_empInfo;
let G_cmpnyInfo;
let G_cmpny_nm_list = [];
var empList = [];

var perMgt = (function () {
    var per = {};

    /*겸직 회사 목록*/
    per.cmpnyNmData = [];

    /*직위*/
    per.deptJdData = [];

    /*직책*/
    per.deptJtData = [];

    /*부서목록*/
    per.deptListData = [];

    /*직위*/
    per.modalDeptJdData = [];

    /*직책*/
    per.modalDeptJtData = [];

    /*부서목록*/
    per.modalDeptListData = [];

    /*부서목록모달*/
    per.deptListModalData = [];

    per.perDataGrid;
    per.perProperties = {};
    per.perData = {
        resources: []
    }
    per.perEmpDataGrid;
    per.perEmpProperties = {};
    per.perEmpData = {
        resources: []
    }

    per.init = function (globalOpt) {
        var param ={};
        G_cmpny_nm_list = ocb.cmm.getCmpnyList(param).cmpnyList;
        G_empInfo = ocb.cmm.getMyEmpInfo();
        //console.log("G_cmpny_nm_list ? ", G_cmpny_nm_list);
        renderComp(this);
        attachEvent(this);
        initDataLoad(this);
    };

    let renderComp = function (obj) {
        createSelectBox();
        perCreateGrid(obj);
    };

    let attachEvent = function (obj) {

    };

    let initDataLoad = function (obj) {

        var param = {};
        param.cmpnyId = SBUxMethod.get('cmpnyNm');
        getEmpList(param);
    };

    var createSelectBox = function() {
        var cmpnyNm = G_cmpny_nm_list;

        cmpnyNm.forEach(function(ele){
            ele.text =  ''+ ele.cmpnyNm;
            ele.value = ''+ ele.cmpnyId;
        });

        /*겸직 회사 목록*/
        per.cmpnyNmData = cmpnyNm;

        SBUxMethod.refresh('cmpnyNm');
        SBUxMethod.refresh('modalCmpnyNm');

        perMgt.setDeptJdJt(SBUxMethod.get('cmpnyNm'), 'main');
    }

    var getEmpList = function(param) {
        param.pageVO = ocb.cmm.getGridPagingParam(per.perDataGrid);
        param.grpId = G_empInfo.grpId;
        console.log("param ? ", param);
        ocb.restcli.exchangeSync('POST', page_context_path + '/rest/department/manage/hist/info/employee/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retObj = res.data;
                console.log("retObj ? ", retObj);
                console.log("retObj ? ", typeof retObj);
                if (retObj) {
                    empList = retObj ? retObj:[];
                    empList.forEach(function(ele){
                        ele.empId = ''+ ele.empId;
                        ele.empNm = ele.empNm ? ''+ ele.empNm:'';
                        ele.loginId = ele.loginId ? ele.loginId:'';
                    })
                    var totalCnt = 0;
                    if (empList.length > 0) {
                        totalCnt = retObj[0].pageVO.totalCnt;
                    }
                    per.perDataGrid.setPageTotalCount(totalCnt);
                    per.perData.resources = empList;
                    per.perDataGrid .refresh();
                }
            } else {
                alert('사원 정보를 불러오는데 실패하였습니다.');
            }
        }, function(res){
            alert(res.message);
        });
    }

    let perCreateGrid = function () {

        var paging = {'type': 'page', 'count': 5, 'size': 10, 'sorttype': 'all', 'showgoalpageui': true};
        per.perDataGrid  = sbuxComponent.makeGrid(per.perDataGrid , per.perProperties, 'perGrid', 'perMgt.perDataGrid','perMgt.perData.resources', '데이터가 존재하지 않습니다.',perCreateGridColumns(), paging);
        per.perDataGrid.bind("beforepagechanged", gridPagingClick);
        per.perDataGrid.bind("afterpagechanged", "appendGridPageUI");
        per.perDataGrid.bind("afterrefresh", "appendGridPageUI");
        per.perDataGrid.bind("afterrebuild", "appendGridPageUI");

    };

    let perEmpListCreateGrid = function () {

        per.perEmpDataGrid  = sbuxComponent.makeGrid(per.perEmpDataGrid , per.perEmpProperties, 'deptEmpGridArea', 'perMgt.perEmpDataGrid','perMgt.perEmpData.resources', '데이터가 존재하지 않습니다.',perEmpListCreateGridColumns());
        per.perEmpDataGrid.bind('click', empGridRowClick);

    };

    let gridPagingClick = function (){
        var param = {};
        param.cmpnyId = SBUxMethod.get('cmpnyNm');
        getEmpList(param);
    }

    per.searhEmpList = function() {
        var param = {};
        param.cmpnyId = SBUxMethod.get('cmpnyNm');
        param.empNm = SBUxMethod.get('empNm');
        param.deptNm = SBUxMethod.get('deptNm');
        param.rspofcId = SBUxMethod.get('deptJt');    /*직책*/
        param.clsfId = SBUxMethod.get('deptJd');      /*직위*/
        getEmpList(param);
    }

    per.setDeptJdJt = function(obj, type) {
        var param = {};
        param.cmpnyId = obj;
        var jobTitles = ocb.cmm.getJobTitle(param);

        jobTitles.jtTxtData.forEach(function(ele){
            ele.text = '' + ele.rspofcNm;
            ele.value = typeof ele.rspfcId != 'undefined' ? '' + ele.rspfcId : '';
        });

        jobTitles.jdTxtData.forEach(function (ele){
            ele.text = '' + ele.rspofcNm;
            ele.value = typeof ele.rspfcId != 'undefined' ? '' + ele.rspfcId : '';
        });

        if (type != 'modal') {
            /*직책*/
            per.deptJtData = jobTitles.jtTxtData;
            /*직위*/
            per.deptJdData = jobTitles.jdTxtData;

            param.empId = G_empInfo.empId;
            var deptInfo = ocb.cmm.getDeptList(param);
            /*부서목록*/
            per.deptListData = deptInfo.deptList;

            SBUxMethod.refresh('deptJd');
            SBUxMethod.refresh('deptJt');
            SBUxMethod.refresh('deptNm');
        } else if (type === 'modal') {
            console.log("obj " + obj + ", type " + type);
            /*직책*/
            per.modalDeptJtData = jobTitles.jtTxtData;
            /*직위*/
            per.modalDeptJdData = jobTitles.jdTxtData;

            param.empId = G_empInfo.empId;
            var deptInfo = ocb.cmm.getDeptList(param);
            /*부서목록*/
            per.modalDeptListData = deptInfo.deptList;

            SBUxMethod.refresh('modalSearchDeptNm');
            SBUxMethod.refresh('modalDeptJd');
            SBUxMethod.refresh('modalDeptJt');
            SBUxMethod.refresh('modalDeptNm');
        }

    }

    per.modalCallBack = function() {
        perEmpListCreateGrid();
        //var paging = {'type': 'page', 'count': 5, 'size': 10, 'sorttype': 'all', 'showgoalpageui': true};

        perMgt.setModalTree();

        document.querySelector('#modal_per').addEventListener("click" , function(e) {
            /*let flag = confirm("yes || no")
            if(flag) {*/
                SBUxMethod.closeModal('modal_per')
            /*}*/
        })
        document.querySelector('.sbux-mol-dlg').addEventListener("click" , function(e) {
            e.stopPropagation()
        })
    }

    per.modalClean = function() {
        SBUxMethod.refresh("modal_per" , {callbackAfterOpen : undefined});
        SBUxMethod.refresh("modal_per" , {callbackAfterOpen : "perMgt.modalCallBack()"});
    }

    per.deptClick = function(obj){
        let param = {};
        param.cmpnyId = obj.customData.cmpnyId;
        param.id = obj.id;

        getEmployeeList(param);
    }

    per.setModalTree = function() {
        var param = {};
        param.cmpnyId = SBUxMethod.get('modalCmpnyNm');

        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retObj = res.data;
                //console.log("getMenuList retObj ? ", retObj);
                if (retObj) {
                    per.deptListModalData = retObj ? retObj:[];
                    //sbux-tre-empty-deptNmTree

                    per.deptListModalData.forEach(function(ele){
                        ele.id = ''+ ele.id;
                        ele.pid = ele.pid ? ''+ ele.pid:'';
                    });

                    SBUxMethod.refresh('deptNmTree');
                    if (per.deptListModalData.length === 0) {
                        document.getElementById('sbux-tre-empty-deptNmTree').innerHTML = "데이터가 없습니다.";
                    }

                }
            } else {
                alert(res.message);
            }
        }, function(res){
            alert(res.message);
        });

        perMgt.setDeptJdJt(SBUxMethod.get('modalCmpnyNm'), 'modal');

        //회사 선택 후 부서원 그리드 초기화
        perMgt.perEmpData.resources= [];
        per.perEmpDataGrid.refresh();

        SBUxMethod.refresh('deptChk');
        SBUxMethod.refresh('deptJdChk');
        SBUxMethod.refresh('deptJtChk');

        perMgt.setCheck(SBUxMethod.get("deptChk"), "deptChk");
        perMgt.setCheck(SBUxMethod.get("deptJdChk"), "deptJdChk");
        perMgt.setCheck(SBUxMethod.get("deptJtChk"), "deptJtChk");
    }

    per.setDeptInfo = function() {
        var param = {};
        param.deptEmpMapngList = [];

        var cnt = per.perEmpDataGrid.getCheckedRowData(0).length;
        var empList = per.perEmpDataGrid.getCheckedRowData(0).data;
        if (cnt == 0) {
            alert("인사이동할 사원을 선택해주세요.");
            return;
        }

        for (var i=0; i<cnt; i++) {
            //rspofcId : 직책, clsfId : 직위
            param.deptEmpMapngList.push({"dlngCd" : "HMOV", "empId": empList[i].empId, "deptId": SBUxMethod.get('modalDeptNm'), "rspofcId" : SBUxMethod.get('modalDeptJt'), "clsfId" : SBUxMethod.get('modalDeptJd')});
        }
        console.log("sava param ? ", param);
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/employee/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retObj = res.data;
                if (retObj) {
                    alert("저장했습니다.");
                }
            } else {
                alert(res.message);
            }
        }, function(res){
            alert(res.message);
        });
    }

    per.setCheck = function(obj, name) {

        if (name === "deptChk") {

            obj.deptChk === true ? SBUxMethod.attr('modalDeptNm','readonly',false) : SBUxMethod.attr('modalDeptNm','readonly',true);

        } else if (name === "deptJdChk") {

            obj.deptJdChk === true ? SBUxMethod.attr('modalDeptJd','readonly',false) : SBUxMethod.attr('modalDeptJd','readonly',true);

        } else if (name === "deptJtChk") {
            obj.deptJtChk === true ? SBUxMethod.attr('modalDeptJt','readonly',false) : SBUxMethod.attr('modalDeptJt','readonly',true);

        }

    }

    var getEmployeeList = function(param){
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/employee/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retList = res.data;
                //console.log("부서원 목록 조회 결과 >>> " , retList);
                perMgt.perEmpData.resources= retList;
                per.perEmpDataGrid.refresh();
            } else {
                alert('부서원 목록을 불러오는데 실패하였습니다.');
            }
        }, function(res){
            alert(res.message);
        });
    }

    var empGridRowClick = function() {

        let nRow = per.perEmpDataGrid.getRow();
        let param = per.perEmpDataGrid.getRowData(nRow,true);
        setDept(param);
    }

    var setDept = function(param) {

        //rspofcId : 직책(JT), clsfId : 직위(JD)
        SBUxMethod.set("modalDeptNm",param.deptVO.text);
        SBUxMethod.set("modalDeptJd",param.clsfId);
        SBUxMethod.set("modalDeptJt",param.rspofcId);

        perMgt.setCheck( SBUxMethod.get('deptChk'), "deptChk");
        perMgt.setCheck( SBUxMethod.get('deptJdChk'), "deptJdChk");
        perMgt.setCheck( SBUxMethod.get('deptJtChk'), "deptJtChk");

    }

    let perCreateGridColumns = function() {
        return [
            {
                caption: ['발령일자','발령일자'],
                ref: 'gnfdDd',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
                , format : {
                    type :'custom'
                    , callback : function (gnfdDd){
                        return moment(Number(gnfdDd)).format('YYYY-MM-DD');
                    }
                }
            },
            {
                caption: ['회사','회사'],
                ref: 'cmpnyNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['사원번호','사원번호'],
                ref: 'empId',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['이름(ID)','이름(ID)'],
                ref: 'empNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['변경전','부서'],
                ref: 'beforeDeptNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['변경전','직위'],
                ref: 'beforePostionNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['변경전', '직책'],
                ref: 'beforeClassNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['변경후','부서'],
                ref: 'deptNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['변경후','직위'],
                ref: 'positionNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['변경후','직책'],
                ref: 'classNm',
                width: '10%',
                style: 'text-align:center',
                type: 'output'
            }
        ];
    }

    let perEmpListCreateGridColumns = function() {
        return [
            {
                caption : ['']
                , ref : 'chkYn'
                , width : '10%'
                , style : 'text-align:center'
                , type : 'checkbox'
                , typeinfo : {
                    fixedcellcheckbox : {
                        usemode : true
                        , rowindex : 0
                    }
                }
            },
            {
                caption: ['부서'],
                ref: 'deptVO',
                width: '25%',
                style: 'text-align:center',
                type: 'output'
                , format : {
                    type :'custom'
                    , callback : function (deptVO){
                        return deptVO.text;
                    }
                }
            },
            {
                caption: ['직위'],
                ref: 'clsfNm',
                width: '25%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['직책'],
                ref: 'rspofcNm',
                width: '25%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: ['이름(ID)'],
                ref: 'empVO',
                width: '25%',
                style: 'text-align:center',
                type: 'output'
                , format : {
                    type :'custom'
                    , callback : function (empVO){
                        return empVO.empNm;
                    }
                }
            }
        ];
    }
    return per;
})();