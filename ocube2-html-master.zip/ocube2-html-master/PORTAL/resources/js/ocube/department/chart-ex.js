
var typeSelectData = [
	{ text : "사원명",		value : "empNm"},
	{ text : "부서명",		value : "deptNm"},
	{ text : "직급",			value : "positionNm"},
	{ text : "직책",			value : "classNm"},
	{ text : "전화번호",		value : "telno1"}
];

var empData	   = [];
var jdTxtData  = [];
var jtTxtData  = [];

var sb_deptEmpGridData = {
	"resources": []
};

var deptEmpGridProperties = {};
var deptChartList = [];
var deptEmpList = [];
let G_grp_id;
let G_cmpny_id;
let deptEmpGridId;

var chart = (function(){
	var v = {};

	v.init = function(globalOpt) {
		G_grp_id = globalOpt.grpId;
		G_cmpny_id = globalOpt.cmpnyId;
		renderComp(this);
		initDataLoad(this);
	}

	var renderComp = function(obj) {
		createDeptEmpGrid();
	}
	var initDataLoad = function(obj) {
		var param = {};
		param.grpId = G_grp_id;
		param.cmpnyId = G_cmpny_id;
		getDeptChart(param);
		var jobTitles = ocb.cmm.getJobTitle(param);
		jdTxtData = jobTitles.jdTxtData;
		jtTxtData= jobTitles.jtTxtData;
		//getJobTitle(param);
	}

	var getJobTitle = function(param) {
		param.useYn = "Y"
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/jobtitle/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retObj = res.data;
				if (retObj) {
					jdTxtData = retObj.filter(function(ele){
						if (ele.gbCd === 'JD') {
							return  ele;
						}
					});

					jtTxtData = retObj.filter(function(ele){
						if (ele.gbCd === 'JT') {
							return  ele;
						}
					});

					jdTxtData.forEach(function(ele){
						ele.value = ''+ ele.rspofcNm;
						ele.label = ele.rspofcNm ? ''+ ele.rspofcNm:'';
					});

					jtTxtData.forEach(function(ele){
						ele.value = ''+ ele.rspofcNm;
						ele.label = ele.rspofcNm ? ''+ ele.rspofcNm:'';
					});
				}
			} else {
				alert('직위 직책 정보를 조회하는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
	}

	var getDeptChart = function(param) {
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retObj = res.data;
				if (retObj) {
					deptChartList = retObj ? retObj:[];
					deptChartList.forEach(function(ele){
						ele.id = ''+ ele.id;
						ele.pid = ele.pid ? ''+ ele.pid:'';
						ele.link = ele.link ? ele.link:'';
					});
					SBUxMethod.refresh('deptChart');
				}
			} else {
				alert('조직도를 조회하는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
	}

	var getEmployeeList = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/employee/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retList = res.data;
				//console.log("부서원 목록 조회 결과 >>> " , retList);
				sb_deptEmpGridData.resources = retList;
				deptEmpGridId.refresh();
			} else {
				alert('부서원 목록을 불러오는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
	}

	v.searchChart = function() {

		var param = {};
		param.grpId = G_grp_id;
		param.cmpnyId = G_cmpny_id;
		var type = SBUxMethod.get("typeSelect");

		if (type === "empNm" ) {
			param.empNm = SBUxMethod.get("searchTxt");
		} else if (type === "deptNm") {
			param.deptNm = SBUxMethod.get("searchTxt");
		} else if (type === "positionNm") {
			param.positionNm = SBUxMethod.get("searchTxt");
		} else if (type === "classNm") {
			param.classNm = SBUxMethod.get("searchTxt");
		} else if (type === "telno1") {
			param.telno1 = SBUxMethod.get("searchTxt");
		}

		getEmployeeList(param);
	}

	v.typeChange = function(obj) {
		//alert(obj);

		/*var param = {};
		param.grpId = G_grp_id;
		param.cmpnyId = G_cmpny_id;
		getJobTitle(param);*/

		if (obj === "empNm" ) {

		} else if (obj === "deptNm") {

		} else if (obj === "positionNm") {
			console.log("jdTxtData ? ", jdTxtData);
			SBUxMethod.attr("searchTxt", "autocomplete-ref", "jdTxtData");
		} else if (obj === "classNm") {
			console.log("jtTxtData ? ", jtTxtData);
			SBUxMethod.attr("searchTxt", "autocomplete-ref", "jtTxtData");
		}

		SBUxMethod.refresh('searchTxt');
	}

	v.deptClick = function(obj) {
		//console.log("obj ", obj);
		let param = {};
		param.cmpnyId = obj.customData.cmpnyId;
		param.id = obj.id;

		getEmployeeList(param);
	}


	var createDeptEmpGrid = function(){

		deptEmpGridId  = sbuxComponent.makeGrid(deptEmpGridId , deptEmpGridProperties, 'deptEmpGridArea', 'deptEmpGridId','sb_deptEmpGridData.resources', '데이터가 존재하지 않습니다.',deptEmpGridColumns());

	};

	var deptEmpGridColumns = function(){
		return [
			 {
				caption : ['부서']
				, ref : 'deptVO'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (deptVO){
						return deptVO.text;
					}
				}
			}
			, {
				caption : ['직급']
				, ref : 'clsfNm'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : ['직책']
				, ref : 'rspofcNm'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : ['이름']
				, ref : 'empVO'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (empVO){
						return empVO.empNm;
					}
				}
			}
			, {
				caption : ['전화번호']
				, ref : 'empVO'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (empVO){
						return empVO.telno1;
					}
				}
			}
		];
	}

	return v;
})();