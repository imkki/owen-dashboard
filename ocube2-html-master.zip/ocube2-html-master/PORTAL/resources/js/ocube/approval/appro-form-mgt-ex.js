var formMgt = (function () {
    let aForm = {};

    aForm.selGroupUseYn = [
        {
            text: "사용",
            value: 'Y'
        },
        {
            text: "미사용",
            value: 'N'
        }
    ]

    aForm.selGroupFormName = [
        {
            text: "기안그룹명1",
            value: '1'
        }
    ]
    aForm.selComName = [
        {
            text: "회사이름1",
            value: '1'
        }
    ]

    aForm.selFormClass = [
        {
            text: "휴가",
            value: '1'
        }
    ]

    aForm.formDataGrid;
    aForm.formProperties = {};
    aForm.formData = {
        resources: []
    }
    aForm.tabFormDataGrid;
    aForm.tabFormProperties = {};
    aForm.tabFormData = {
        resources: []
    }
    aForm.selFormNumDataGrid;
    aForm.selFormNumProperties = {};
    aForm.selFormNumData = {
        resources: []
    }
    aForm.formNumDataGrid;
    aForm.formNumProperties = {};
    aForm.formNumData = {
        resources: []
    }
    aForm.tabDeptDataGrid;
    aForm.tabDeptProperties = {};
    aForm.tabDeptData = {
        resources: []
    }
    aForm.formNmDataGrid;
    aForm.formNm1DataGrid;
    aForm.formNm2DataGrid;
    aForm.formNmProperties = {};
    aForm.formNmData = {
        resources: []
    }

    aForm.init = function (globalOpt) {
        renderComp(this);
        attachEvent(this);
        initDataLoad(this);
    };

    let renderComp = function (obj) {
        formNameGrid('tab_name_add','formNm2DataGrid');
    };

    let attachEvent = function (obj) {
    };

    let initDataLoad = function (obj) {
        approvalLineGrid();
        deptOpenModalGrid();
        formNumModalGrid();
        selFormNumModalGrid();
    };
    // 그리드 네임
    let approvalLineGrid = function () {
        aForm.formProperties.parentid = 'sub_approval_line';
        aForm.formProperties.id = 'formMgt.formDataGrid';
        aForm.formProperties.jsonref = 'formMgt.formData.resources';
        aForm.formProperties.emptyrecords = '데이터가 없습니다.';
        aForm.formProperties.columns =  approvalLineGridColumns();
        aForm.formDataGrid = _SBGrid.create(aForm.formProperties);
    };

    let approvalLineModalGrid = function () {
        aForm.tabFormProperties.parentid = 'sub_tab_approval_line';
        aForm.tabFormProperties.id = 'formMgt.tabFormDataGrid';
        aForm.tabFormProperties.jsonref = 'formMgt.tabFormData.resources';
        aForm.tabFormProperties.emptyrecords = '데이터가 없습니다.';
        aForm.tabFormProperties.columns =  approvalLineModalColumns();
        aForm.tabFormDataGrid = _SBGrid.create(aForm.tabFormProperties);
    };
    let formNumModalGrid = function () {
        aForm.formNumProperties.parentid = 'form_num';
        aForm.formNumProperties.id = 'formMgt.formNumDataGrid';
        aForm.formNumProperties.jsonref = 'formMgt.formNumData.resources';
        aForm.formNumProperties.emptyrecords = '데이터가 없습니다.';
        aForm.formNumProperties.columns =  formNumObjModalColumns();
        aForm.formNumDataGrid = _SBGrid.create(aForm.formNumProperties);
    };
    let selFormNumModalGrid = function () {
        aForm.selFormNumProperties.parentid = 'sel_form_num';
        aForm.selFormNumProperties.id = 'formMgt.selFormNumDataGrid';
        aForm.selFormNumProperties.jsonref = 'formMgt.selFormNumData.resources';
        aForm.selFormNumProperties.emptyrecords = '데이터가 없습니다.';
        aForm.selFormNumProperties.columns =  selFormNumObjModalColumns();
        aForm.selFormNumDataGrid = _SBGrid.create(aForm.selFormNumProperties);
    };
    let deptOpenModalGrid = function () {
        aForm.tabDeptProperties.parentid = 'sub_tab_dept_open';
        aForm.tabDeptProperties.id = 'formMgt.tabDeptDataGrid';
        aForm.tabDeptProperties.jsonref = 'formMgt.tabDeptData.resources';
        aForm.tabDeptProperties.emptyrecords = '데이터가 없습니다.';
        aForm.tabDeptProperties.columns =  deptOpenModalColumns();
        aForm.tabDeptDataGrid = _SBGrid.create(aForm.tabFormProperties);
    };

    let formNameGrid = function (divId , id) {
        aForm.formNmProperties.parentid = divId;
        aForm.formNmProperties.id = id;
        aForm.formNmProperties.jsonref = 'formMgt.formNmData.resources';
        aForm.formNmProperties.columns = formNmGridColumns();
        window[id] = _SBGrid.create(aForm.formNmProperties);
    };

    aForm.modalCallBack = function(){
        formNameGrid('group_name_add','formNmDataGrid');
        formNameGrid('form_name_add','formNm1DataGrid');
    }

    aForm.fnAfterSelectTab = function(){
        approvalLineModalGrid();
    }

    let approvalLineGridColumns = function () {
        return [
            {caption: ['순서'], ref: 'A', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'B', width: '30%', style: 'text-align:center', type: 'output'},
            {caption: ['직위/직책'], ref: 'C', width: '30%', style: 'text-align:center', type: 'output'},
            {caption: ['이름'], ref: 'D', width: '30%', style: 'text-align:center', type: 'output'}
        ];
    }

    let approvalLineModalColumns = function () {
        return [
            {caption: [''], ref: 'D', width: '5%', style: 'text-align:center', type: 'output'},
            {caption: ['순서'], ref: 'A', width: '5%', style: 'text-align:center', type: 'output'},
            {caption: ['회사'], ref: 'A', width: '22.5%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'B', width: '22.5%', style: 'text-align:center', type: 'output'},
            {caption: ['직위/직책'], ref: 'C', width: '22.5%', style: 'text-align:center', type: 'output'},
            {caption: ['이름'], ref: 'D', width: '22.5%', style: 'text-align:center', type: 'output'}
        ];
    }

    let deptOpenModalColumns = function () {
        return [
            {caption: [''], ref: 'D', width: '20%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'B', width: '80%', style: 'text-align:center', type: 'output'}
        ];
    }

    let formNumObjModalColumns = function () {
        return [
            {caption: [''], ref: 'D', width: '20%', style: 'text-align:center', type: 'output'},
            {caption: ['채번코드'], ref: 'B', width: '40%', style: 'text-align:center', type: 'output'},
            {caption: ['설명'], ref: 'B', width: '40%', style: 'text-align:center', type: 'output'}
        ];
    }

    let selFormNumObjModalColumns = function () {
        return [
            {caption: [''], ref: 'D', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['순서'], ref: 'B', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['채번코드'], ref: 'B', width: '35%', style: 'text-align:center', type: 'output'},
            {caption: ['설명'], ref: 'B', width: '35%', style: 'text-align:center', type: 'output'}
        ];
    }
    let formNmGridColumns = function(){
        return [
            {
                caption : '언어'
                , ref : 'langCd'
                , width : '30%'
                , style : 'text-align:center'
                , type : 'output'
                , format : {
                    type :'custom'
                    , callback : function(langCd){
                        return ocb.cmm.getLanguagesList(langCd);
                    }
                }
            }
            , {
                caption : '명칭'
                , ref : 'deptNm'
                , width : '70%'
                , style : 'text-align:center'
                , type : 'input'
                , typeinfo : {
                    maxlength : 30
                }
            }
        ];
    }
    aForm.treeFormGroupName = [
        { "id" : "0",     "pid" : "-1", "order" : "1", "text" : "관심사",    "value" : "" , "cssstyle": "font-size:14px;" },
        { "id" : "4_2_3", "pid" : "4_2","order" : "3", "text" : "오픈카",    "value" : ""  },
        { "id" : "4_1",   "pid" : "4",  "order" : "1", "text" : "자전거",    "value" : ""  },
        { "id" : "4_2_1", "pid" : "4_2","order" : "1", "text" : "클래식",    "value" : ""  },
        { "id" : "4_2",   "pid" : "4",  "order" : "2", "text" : "자동차",    "value" : ""  },
        { "id" : "4",     "pid" : "0",  "order" : "4", "text" : "이동수단",  "value" : ""  },
        { "id" : "4_4",   "pid" : "4",  "order" : "4", "text" : "보트",      "value" : ""  },
        { "id" : "4_2_4", "pid" : "4_2","order" : "4", "text" : "쿠페",      "value" : "A" },
        { "id" : "4_3",   "pid" : "4",  "order" : "3", "text" : "모터싸이클","value" : ""  },
        { "id" : "1",     "pid" : "0",  "order" : "1", "text" : "여가활동",  "value" : "B" },
        { "id" : "2",     "pid" : "0",  "order" : "2", "text" : "주거",      "value" : ""  },
        { "id" : "2_1",   "pid" : "2",  "order" : "1", "text" : "주택",      "value" : ""  },
        { "id" : "2_2",   "pid" : "2",  "order" : "2", "text" : "아파트",    "value" : "A" }
    ];
    aForm.tabFormMgt = [
        { "id" : "0", "pid" : "-1", "order" : "1", "text" : "기본정보", "targetid" : "tab_1" },
        { "id" : "1", "pid" : "-1", "order" : "2", "text" : "양식설정", "targetid" : "tab_2"},
        { "id" : "2", "pid" : "-1", "order" : "3", "text" : "결재라인", "targetid" : "tab_3"},
        { "id" : "3", "pid" : "-1", "order" : "4", "text" : "공개부서", "targetid" : "tab_4"},
        { "id" : "4", "pid" : "-1", "order" : "5", "text" : "채번설정", "targetid" : "tab_5"}
    ];
    aForm.subTabFormMgt = [
        { "id" : "0", "pid" : "-1", "order" : "1", "text" : "결재", "targetid" : "tab_3_1" },
        { "id" : "1", "pid" : "-1", "order" : "2", "text" : "수신참조", "targetid" : "tab_3_2"}
    ];
    aForm.subModalTabFormMgt = [
        { "id" : "0", "pid" : "-1", "order" : "1", "text" : "결재", "targetid" : "tab_3_1_1" },
        { "id" : "1", "pid" : "-1", "order" : "2", "text" : "수신참조", "targetid" : "tab_3_1_2"}
    ];

    return aForm;
})();