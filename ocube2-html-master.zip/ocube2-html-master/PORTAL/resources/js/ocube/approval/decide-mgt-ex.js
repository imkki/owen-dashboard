var deMgt = (function () {
    let de = {};

    de.selGroupUseYn = [
        {
            text: "사용",
            value: 'Y'
        },
        {
            text: "미사용",
            value: 'N'
        }
    ]

    de.selGroupFormName = [
        {
            text: "기안그룹명1",
            value: '1'
        }
    ]
    de.selComName = [
        {
            text: "회사이름1",
            value: '1'
        }
    ]

    de.selFormClass = [
        {
            text: "휴가",
            value: '1'
        }
    ]

    de.formDataGrid;
    de.formProperties = {};
    de.formData = {
        resources: []
    }
    de.tabFormDataGrid;
    de.tabFormProperties = {};
    de.tabFormData = {
        resources: []
    }


    de.init = function (globalOpt) {
        renderComp(this);
        attachEvent(this);
        initDataLoad(this);
    };

    let renderComp = function (obj) {
        formNameGrid('tab_name_add','formNm2DataGrid');
    };

    let attachEvent = function (obj) {
    };

    let initDataLoad = function (obj) {
        approvalLineGrid();
        deptOpenModalGrid();
        formNumModalGrid();
        selFormNumModalGrid();
    };
    // 그리드 네임
    let approvalLineGrid = function () {
        aForm.formProperties.parentid = 'sub_approval_line';
        aForm.formProperties.id = 'formMgt.formDataGrid';
        aForm.formProperties.jsonref = 'formMgt.formData.resources';
        aForm.formProperties.emptyrecords = '데이터가 없습니다.';
        aForm.formProperties.columns =  approvalLineGridColumns();
        aForm.formDataGrid = _SBGrid.create(aForm.formProperties);
    };

    let approvalLineModalGrid = function () {
        aForm.tabFormProperties.parentid = 'sub_tab_approval_line';
        aForm.tabFormProperties.id = 'formMgt.tabFormDataGrid';
        aForm.tabFormProperties.jsonref = 'formMgt.tabFormData.resources';
        aForm.tabFormProperties.emptyrecords = '데이터가 없습니다.';
        aForm.tabFormProperties.columns =  approvalLineModalColumns();
        aForm.tabFormDataGrid = _SBGrid.create(aForm.tabFormProperties);
    };


    de.modalCallBack = function(){
        approvalLineModalGrid();
    }

    let approvalLineGridColumns = function () {
        return [
            {caption: ['순서'], ref: 'A', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'B', width: '30%', style: 'text-align:center', type: 'output'},
            {caption: ['직위/직책'], ref: 'C', width: '30%', style: 'text-align:center', type: 'output'},
            {caption: ['이름'], ref: 'D', width: '30%', style: 'text-align:center', type: 'output'}
        ];
    }

    let approvalLineModalColumns = function () {
        return [
            {caption: [''], ref: 'D', width: '5%', style: 'text-align:center', type: 'output'},
            {caption: ['순서'], ref: 'A', width: '5%', style: 'text-align:center', type: 'output'},
            {caption: ['회사'], ref: 'A', width: '22.5%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'B', width: '22.5%', style: 'text-align:center', type: 'output'},
            {caption: ['직위/직책'], ref: 'C', width: '22.5%', style: 'text-align:center', type: 'output'},
            {caption: ['이름'], ref: 'D', width: '22.5%', style: 'text-align:center', type: 'output'}
        ];
    }
    return de;
})();