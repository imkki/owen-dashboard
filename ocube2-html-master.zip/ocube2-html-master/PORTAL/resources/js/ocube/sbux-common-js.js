var sbuxComponent = (function(){
    var v = {};

    v.makeGrid = function (gridObj, gridProps, parentId, id, jsonref, emptyrecords, columns, paging) {
        gridProps.parentid = parentId;
        gridProps.id = id;
        gridProps.jsonref = jsonref;
        gridProps.emptyrecords = emptyrecords;
        gridProps.columns = columns;
        if (typeof paging != 'undefined') {
            gridProps.paging = paging;

        }
        gridObj = _SBGrid.create(gridProps);
        return gridObj;
    }

    v.createGrid = function (parentId, id, jsonref, columns, resize, pagingOpt, treeOpt) {
        let gridObj;
        let gridProps = {};
        gridProps.parentid = parentId;
        gridProps.id = id;
        gridProps.jsonref = jsonref;
        gridProps.columns = columns;
        gridProps.allowuserresize = resize ? resize : false;
        if (typeof pagingOpt !== 'undefined' && pagingOpt != null && pagingOpt) {
            gridProps.paging = pagingOpt;
        }
        if (typeof treeOpt !== 'undefined' && treeOpt != null && treeOpt) {
            gridProps.tree = treeOpt;
        }
        gridProps.rowheight = '30';
        gridProps.fixedrowheight = '30';
        gridProps.emptyrecords = message.springMsg.gridemptyrecords;
        gridObj = _SBGrid.create(gridProps);
        return gridObj;
    }

    return v;
})();