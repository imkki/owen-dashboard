var optionMgtEx = (function(){
	let op = {};
	op.sb_cmpnyList = [];	
	op.optListGridId;		// 옵션 목록 그리드
	op.optListGridProperties = {};
	op.sb_optListGridData = [];
	
	let isMaster = false;	// true : MASTER, false : ADMIN	
	let g_grpYn = false; 	// 그룹/회사 구분 (true : 그룹, false : 회사)
	let g_msg;				// properties msg
	let g_c_msg;			// 공통 properties msg
	let g_grpId;
	let g_cmpnyId;
	
	op.init = function(globalOpt){
		g_msg = globalOpt.springMsg;
		g_c_msg = message.springMsg;	// 공통 msg

		let g_empInfo = ocb.cmm.getMyEmpInfo();	
		isMaster = g_empInfo.master;
		g_grpYn = isMaster;				// 마스터일 경우, 초기값 그룹으로 세팅
		g_grpId = g_empInfo.grpId;
		g_cmpnyId = g_empInfo.cmpnyId;

		if(isMaster){
			SBUxMethod.show('select_cmpny');
			$('#applyGroupAdminArea').hide();
			SBUxMethod.attr('txt_itemDc', 'readonly', 'false');
		}else{
			SBUxMethod.hide('select_cmpny');
			$('#applyGroupAdminArea').show();
			SBUxMethod.attr('txt_itemDc', 'readonly', 'true');
			SBUxMethod.set('label_cmpnyNm', '적용회사');
		}
		getMyCmpnyList();	// 내 회사목록 조회

		$('#optDetailInfoArea').css('visibility', 'hidden');	// 상세 정보 영역 hide
		
		renderComp(this);
		initDataLoad(this);
	};

	let renderComp = function(obj){
		createOptListGrid();
	};

	let initDataLoad = function(obj){
		let param = {};
		param.grpId = g_grpId;
		if( !g_grpYn ) {
			param.cmpnyId = g_cmpnyId;
		}
		getOptList(param);
	};

	// [API] 전체 옵션 리스트 조회
	let getOptList = function(param) {
		let urlType = param.cmpnyId ? 'info' : 'grp'; 	// grp : 그룹, info : 회사
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/option/manage/' + urlType + '/list', JSON.stringify(param), 'application/json', true, function (res) { // success callback
			op.sb_optListGridData = res.data;
			op.optListGridId.refresh();
		}, function (res) {
			alert(g_msg.alertMsgFailOptList);
		});
	};

	// [API] 옵션 정보 수정
	let setOptInfo = function(param){
		let urlType = param.cmpnyId ? 'info' : 'grp';	// grp : 그룹, info : 회사
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/option/manage/' + urlType + '/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			let param = {};
			param.grpId = g_grpId;
			if( !g_grpYn ) {
				param.cmpnyId = g_cmpnyId;
			}
			getOptList(param);
			alert(g_c_msg.alertMsgSave);
		}, function(res){
			alert(g_c_msg.alertMsgSaveTitle + ' ' + g_c_msg.alertMsgFailSuffix);
		});
	};

	// 내 회사정보 - MASTER : List(그룹+회사), ADMIN : 접속 회사
	let getMyCmpnyList = function(){
		let myCmpnyList = ocb.cmm.getMyCmpnyList();	// 내 회사정보
		if(isMaster) {
			op.sb_cmpnyList = [];	// 목록 초기화
			let str = '';
			myCmpnyList.forEach(function(ele, i){
				let addObj = { text : str + ele.cmpnyNm, value : ele.cmpnyId };
				op.sb_cmpnyList.push(addObj);
				if( i === 0 ) { str = ele.cmpnyNm + ' > '; }
			});
			SBUxMethod.refresh('select_cmpny');
		}else{
			$('#applyGroupAdminArea').html(': &nbsp;&nbsp;' + myCmpnyList[0].cmpnyNm );
		}
	};

	let optListGridRowClick = function(){
		let selIndex = op.optListGridId.getRow();
		if( selIndex <= 0 ) { return; }

		let selData = op.optListGridId.getRowData(selIndex);
		if( typeof selData.itemValue !== 'undefined' && selData.itemValue !== null && selData.itemValue !== '' ){
			$('#optDetailInfoArea').css('visibility', 'visible');
			SBUxMethod.set('input_itemValue', selData.itemValue);
			SBUxMethod.set('txt_itemDc', selData.itemDc ? selData.itemDc : '');
		} else {
			$('#optDetailInfoArea').css('visibility', 'hidden');
		}
	}

	let createOptListGrid = function(){
		op.optListGridProperties.parentid = 'optListGridArea';
		op.optListGridProperties.id = 'optionMgtEx.optListGridId';
		op.optListGridProperties.jsonref = 'optionMgtEx.sb_optListGridData';
		op.optListGridProperties.allowuserresize = false;
		op.optListGridProperties.rowheight = '40';
		op.optListGridProperties.fixedrowheight = '40';
		op.optListGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		op.optListGridProperties.tree = { col : 0, levelref : 'phase', open : true, lock : true, openlevel : 0 };
		op.optListGridProperties.columns = optListGridColumns();
		op.optListGridId = _SBGrid.create(op.optListGridProperties);

		op.optListGridId.bind('click', optListGridRowClick);
	};

	let optListGridColumns = function(){
		return [
			{
				caption : [g_msg.optGridCol.itemNm]
				, ref : 'itemNm'
				, width : '60%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_msg.optGridCol.itemValue]
				, ref : 'itemValue'
				, width : '40%'
				, style : 'text-align:center'
				, type : 'output'
			}
		];
	};

	// 회사 목록 Change Evt
	op.fnChangeCmpny = function(val){
		$('#optDetailInfoArea').css('visibility', 'hidden');	// 상세 정보 hide
		/*let obj = JSON.parse(SBUxMethod.getValue('select_cmpny'));
		g_grpYn = obj.cmpnyId !== g_grpId && obj.sortSn >= 0; // false -> 그룹이 아닐 경우 (그룹 sortSn : -9999)*/
		let cmpnyId = SBUxMethod.getValue('select_cmpny');
		g_grpYn = cmpnyId === g_grpId;

		let param = {};
		param.grpId = g_grpId;
		if( !g_grpYn ) {
			param.cmpnyId = cmpnyId;
		}
		getOptList(param);
	};

	// 설정값 옵션 저장 버튼
	op.fnClickOptValSave = function(val){
		let nRow = op.optListGridId.getRow();
		let selData = op.optListGridId.getRowData(nRow, true);

		let param = {};
		param.grpId = g_grpId;
		if( !g_grpYn ) {
			param.cmpnyId = selData.cmpnyId;
		}
		param.upperItemCd = selData.upperItemCd;
		param.itemCd = selData.itemCd;
		param.itemNm = selData.itemNm;
		param.itemValue = SBUxMethod.get('input_itemValue');

		if(isMaster) {	// 마스터 권한일 경우에만 설명 수정 가능
			param.itemDc = SBUxMethod.get('txt_itemDc');
		}
		setOptInfo(param);
	};

	return op;
})();