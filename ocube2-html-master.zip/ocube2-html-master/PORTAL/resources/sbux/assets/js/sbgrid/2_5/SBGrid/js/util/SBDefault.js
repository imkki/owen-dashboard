//그리드의 기본 default 속성을 변경하고 싶을 때 사용하면 됨.
var _SBDefault = {PROP : {}};
_SBDefault.PROP.Columns = {
	/*'mask' : {
		alias : "currency",
		prefix : '￦'
	}*/
};

_SBDefault.PROP.Grid = {
	/*'captionareafocusclear' : true
	 *allowcopy : true
	 * allowpaste :  true
	 */
};